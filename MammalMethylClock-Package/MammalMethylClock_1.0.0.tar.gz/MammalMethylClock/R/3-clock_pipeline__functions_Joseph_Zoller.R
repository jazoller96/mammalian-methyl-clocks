## Defining main and helper pipeline functions for clocks and EWAS
## Author: Joseph Zoller

#' Align Normalized Methylation Data with Metadata Sheet Using Sample ID Columns
#' @description Align metadata `info` with normalized methylation data `dat`, by
#'   matching rows that represent each sample, and the removing sample ID's from
#'   `dat`.  This is an important step before doing any analyses or building any
#'   clocks, because the methylation data needs to be unlabeled for use in any
#'   regression models.
#'
#' @param info Data frame, the metadata for the samples
#' @param dat Data frame, the normalized methylation data for the samples
#' @param SAMPVAR.info String, the name of the column in `info` containing
#'   unique sample ID's
#' @param SAMPVAR.dat String, the name of the column in `dat` containing
#'   matching sample ID's
#'
#' @details For the conceptual framework of this package, the file `dat` should
#'   still contain the sample ID's in one of its columns.  In addition, `info`
#'   and `dat` should be formatted such that rows correspond to samples
#'
#'   This function will (if necessary) rearrange and filter the rows of both
#'   data sets so that every row in `info` corresponds to the same row number in
#'   `dat`, and then remove from `dat` the column containing sample ID's.  We
#'   use `ys` and `xs` to refer to these half-labeled data frames that are
#'   returned by this function, and which are ready for use in regression
#'   models.
#'
#'   Note that this function removes all columns of `dat` that do not contain
#'   the string 'cg' in the column name, in order to be compatible with genome
#'   annotation probe mapping files.
#'
#' @return A 2-element list, containing `ys` and `xs`: \item{ys}{The aligned
#'   version of `info`, otherwise unmodified.  As the name suggests, use this
#'   for the 'y' in regression analyses.} \item{xs}{The aligned and modified
#'   verison of `dat`, with the column containing sample ID's removed.}
#' @export
alignDatToInfo <- function(info, dat, SAMPVAR.info, SAMPVAR.dat) {
  if (!(SAMPVAR.info %in% colnames(info))) {
    stop(paste0("SAMPVAR.info=", SAMPVAR.info, " not found"))
  }
  if (!(SAMPVAR.dat %in% colnames(dat))) {
    stop(paste0("SAMPVAR.dat=", SAMPVAR.dat, " not found"))
  }
  info_alignvar <- info[, SAMPVAR.info]
  dat_alignvar <- dat[, SAMPVAR.dat]
  matchid <- match(info_alignvar, dat_alignvar)
  matchid.new <- matchid[which(!is.na(matchid))]
  info.new <- info[which(!is.na(matchid)), ]
  dat.new <- dat[matchid.new, ]
  ys <- info.new
  xs <- as.matrix(dat.new[, which(colnames(dat.new) != SAMPVAR.dat)])
  rownames(xs) <- NULL
  xs <- xs[, which(grepl("cg", colnames(xs)))] # removes probes that don't start with 'cg'
  if (is.vector(xs)) {
    xs <- t(as.matrix(xs))
  }
  yxs.list <- list(ys, xs)
  return(yxs.list)
}

#' Select Probes within a Methylation Dataset Based on Mean Methylation Value
#' @description Find the CpG probes that are detectable within a methylation
#'   data set, as determined by the mean value of methylation across all samples.
#'   The "middle" filter finds all probes that have a mean value sufficient
#'   different from 0.5 (fully ambigious), specified by some threshold.
#'
#' @param xs Data frame, the aligned and normalized methylation data for the
#'   samples (rows are samples).
#'
#'   To format `xs` correctly, use [alignDatToInfo()].
#' @param windowsize Numeric, the minimum difference between mean methylation
#'   and 0.5 such that a probe is not removed by the filter (default is 0.10)
#' @details The mean methylation across all samples is calculated for every
#'   probe. Then, a probe is NOT remove by the filter if the mean methylation
#'   value is greater than `0.5 + windowsize` or less than `0.5 - windowsize`.
#'
#' @return Rturns a string vector containing the names of the CpG probes
#'   remaining, after applying the filtering.
#' @export
selectProbes.middleFilter <- function(xs, windowsize = 0.10) {
  cpg_names_middlefilter <- names(which(abs(colMeans(xs, na.rm = T) - 0.5) > windowsize))
  return(cpg_names_middlefilter)
}

#' Select Probes within a Methylation Dataset Based on Rank P-Values
#' @description [selectProbes.rankPvalue()] finds the CpG probes that are most
#'   significantly correlated (both positively and negatively) with the outcome
#'   variable in a given data set, using rank p-values across a stratifying
#'   variable.
#'
#'   [selectProbesLOSO.rankPvalue()] instead performs a LOSO variation of this
#'   process, by iterating through levels of the stratifying variable.  For each
#'   iteration, it ignores one stratum of the data and then selects the same
#'   number of probes.  Then, it returns a list of multiple sets of probes.
#'
#' @param xs Data frame, the aligned and normalized methylation data for the
#'   samples (rows are samples).
#'
#'   To format `xs` correctly, use [alignDatToInfo()].
#' @param ys Data frame, the aligned metadata for the samples.
#'
#'   To format `ys` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys` containing the outcome
#'   variable (typically Age, in years)
#' @param SPECVAR String, the name of the column in `ys` containing the
#'   stratifying variable (typically Species Name).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param halfsize Integer, the number of probes to be selected with most
#'   significant positive and negative correlations with the outcome variable
#'   (default is `1000`). The function will return sets of probes twice the size
#'   of `halfsize`
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable, with up to two additional parameters.  For more
#'   information, see [saveBuildClock()]
#' @param fun_VAR1 String, the name of the column in `ys` containing the first
#'   parameter of `fun_trans`, if any (default is `NULL`, meaning no parameter
#'   is required)
#' @param fun_VAR2 String, the name of the column in `ys` containing the second
#'   parameter of `fun_trans`, if any (default is `NULL`, meaning no parameter
#'   is required)
#' @details Within this documentation, \eqn{S} refers to `S ==
#'   length(levels(ys[,SPECVAR]))`.
#'
#'   In the function [selectProbes.rankPvalue()], the data is divided into
#'   strata by each level in `SPECVAR`, and within each strata, a vector of
#'   single-probe correlations are calculated (between the transformed outcome
#'   variable and the beta values of a given probe).  This results in a
#'   correlation table of each probe across \eqn{S} strata, which is then used
#'   to calculate rank p-values for each probe, using [WGCNA::rankPvalue()].
#'
#'   In the function [selectProbesLOSO.rankPvalue()], it instead performs a LOSO
#'   variation of this process, which results in \eqn{S} different sets of rank
#'   p-values instead of 1.  The purpose of this function is for properly doing
#'   a LOSO evaluations of a multi-species clock, if the clock was built by
#'   pre-filtering probes based on rank p-value. In this setting, instead of
#'   passing the correlation table directly into [WGCNA::rankPvalue()], it
#'   generates \eqn{S} sub-tables, each with one column removed, and passes each
#'   of them into [WGCNA::rankPvalue()].  This allows the LOSO evaluation to
#'   emulate the pre-filtering process for each of the LOSO iterations
#'   independently.
#'
#' @return [selectProbes.rankPvalue()] returns a string vector of length
#'   `2*halfsize`, containing the names of the most significant CpG probes.
#'
#'   [selectProbesLOSO.rankPvalue()] returns a list of string vectors of length
#'   \eqn{S} (each string vector is of length `2*halfsize`), containing the
#'   names of the most significant CpG probes for each LOSO iteration.
#' @export
selectProbes.rankPvalue <- function(xs, ys, OUTVAR, SPECVAR, halfsize = 2000, fun_trans = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL) {
  rows.keep <- which(!is.na(fun_trans(ys[, OUTVAR], ys[, fun_VAR1], ys[, fun_VAR2])))
  if (length(rows.keep) < nrow(ys)) {
    print(paste(
      nrow(ys) - length(rows.keep),
      "rows in the data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    print("WARNING: Because of this, levels of SPECVAR may have been removed and reordered")
    ys <- ys[rows.keep, ]
    ys[, SPECVAR] <- factor(ys[, SPECVAR])
  }

  ys.species <- ys[, SPECVAR]

  ### Generating correlation table
  cpg_names <- colnames(xs)
  spec_names <- levels(ys.species)
  corr_cpgxspec <- data.frame(matrix(NA, nrow = length(cpg_names), ncol = length(spec_names)))
  rownames(corr_cpgxspec) <- cpg_names
  colnames(corr_cpgxspec) <- spec_names
  for (spec.num in 1:length(spec_names)) {
    indcs <- which(as.numeric(ys.species) == spec.num)
    if (length(indcs) == 0) {
      corr_cpgxspec[, spec.num] <- NA
    } else {
      ys.subspec <- ys[indcs, ]
      xs.subspec <- xs[indcs, ]
      ys.subspec.outcome <- ys.subspec[, OUTVAR]
      ys.subspec.funvar1 <- ys.subspec[, fun_VAR1]
      ys.subspec.funvar2 <- ys.subspec[, fun_VAR2]
      if (!is.na(var(ys.subspec.outcome, na.rm = T)) && var(ys.subspec.outcome, na.rm = T) > 0) {
        corr_cpgxspec[, spec.num] <- cor(fun_trans(ys.subspec.outcome, ys.subspec.funvar1, ys.subspec.funvar2),
                                         xs.subspec,
                                         use = "pairwise.complete.obs"
        )[1, ]
      } else {
        corr_cpgxspec[, spec.num] <- NA
      }
    }
  }
  corr_cpgxspec <- corr_cpgxspec[, which(!is.na(corr_cpgxspec[1, ]))]

  ### Generating rank p-values and selecting CpGs
  rankp_obj <- rankPvalue(corr_cpgxspec)
  cpg_names_rankp_hi <- rownames(rankp_obj[order(rankp_obj$pValueHighRank)[1:halfsize], ])
  cpg_names_rankp_lo <- rownames(rankp_obj[order(rankp_obj$pValueLowRank)[1:halfsize], ])
  cpg_names_rankp_sig <- sort(c(cpg_names_rankp_hi, cpg_names_rankp_lo))
  return(cpg_names_rankp_sig)
}
#' @export
#' @rdname selectProbes.rankPvalue
selectProbesLOSO.rankPvalue <- function(xs, ys, OUTVAR, SPECVAR, halfsize = 2000, fun_trans = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL) {
  rows.keep <- which(!is.na(fun_trans(ys[, OUTVAR], ys[, fun_VAR1], ys[, fun_VAR2])))
  if (length(rows.keep) < nrow(ys)) {
    print(paste(
      nrow(ys) - length(rows.keep),
      "rows in the data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    print("WARNING: Because of this, levels of SPECVAR may have been removed and reordered")
    ys <- ys[rows.keep, ]
    ys[, SPECVAR] <- factor(ys[, SPECVAR])
  }

  ys.species <- ys[, SPECVAR]

  ### Generating correlation table
  cpg_names <- colnames(xs)
  spec_names <- levels(ys.species)
  corr_cpgxspec <- data.frame(matrix(NA, nrow = length(cpg_names), ncol = length(spec_names)))
  rownames(corr_cpgxspec) <- cpg_names
  colnames(corr_cpgxspec) <- spec_names
  for (spec.num in 1:length(spec_names)) {
    indcs <- which(as.numeric(ys.species) == spec.num)
    if (length(indcs) == 0) {
      corr_cpgxspec[, spec.num] <- NA
    } else {
      ys.subspec <- ys[indcs, ]
      xs.subspec <- xs[indcs, ]
      ys.subspec.outcome <- ys.subspec[, OUTVAR]
      ys.subspec.funvar1 <- ys.subspec[, fun_VAR1]
      ys.subspec.funvar2 <- ys.subspec[, fun_VAR2]
      if (!is.na(var(ys.subspec.outcome, na.rm = T)) && var(ys.subspec.outcome, na.rm = T) > 0) {
        corr_cpgxspec[, spec.num] <- cor(fun_trans(ys.subspec.outcome, ys.subspec.funvar1, ys.subspec.funvar2),
                                         xs.subspec,
                                         use = "pairwise.complete.obs"
        )[1, ]
      } else {
        corr_cpgxspec[, spec.num] <- NA
      }
    }
  }
  corr_cpgxspec <- corr_cpgxspec[, which(!is.na(corr_cpgxspec[1, ]))]

  ### Generating rank p-values and selecting CpGs
  cpg_names_rankp_sig.list <- vector("list", length(levels(ys.species)))
  for (spec.num in 1:length(cpg_names_rankp_sig.list)) {
    rankp_obj.num <- rankPvalue(corr_cpgxspec[, -spec.num])
    cpg_names_rankp_hi.num <- rownames(rankp_obj.num[order(rankp_obj.num$pValueHighRank)[1:halfsize], ])
    cpg_names_rankp_lo.num <- rownames(rankp_obj.num[order(rankp_obj.num$pValueLowRank)[1:halfsize], ])
    cpg_names_rankp_sig.num <- sort(c(cpg_names_rankp_hi.num, cpg_names_rankp_lo.num))
    cpg_names_rankp_sig.list[[spec.num]] <- cpg_names_rankp_sig.num
  }
  return(cpg_names_rankp_sig.list)
}

#' Build a New Clock based on a Training Data Set
#' @description Fit an elastic net regression model, trained by using an aligned
#'   metadata `ys.train` and an aligned and normalized methylation data
#'   `xs.train`.  Elastic net regression results in a sparse model, meaning that
#'   most probes will not be selected in the final fitted model.
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Table of Clock coefficients,} \item{Table of metadata
#'   appended with Clock predictions,} \item{Panel plot of regression
#'   diagnostics and Clock predictions.} }
#'
#'   WARNING: This function calls [glmnet::cv.glmnet()], so the results of this
#'   function are subject to randomness. Users should add line in their R
#'   scripts calling [set.seed()] before calling this function, in order for the
#'   results to be reproducible and consistent
#'
#' @param xs.train Data frame, the aligned and normalized methylation data for
#'   the samples in the training set (rows are samples).
#'
#'   To format `xs.train` correctly, use [alignDatToInfo()].
#' @param ys.train Data frame, the aligned metadata for the samples in the
#'   training set.
#'
#'   To format `ys.train` correctly, use [alignDatToInfo()].
#' @param xs.other Data frame, the aligned and normalized methylation data for
#'   additional samples, to which the train Clock should generate predictions.
#'   For example, samples you are considering adding to the training set, or
#'   samples from an experimental or comparison group (rows are samples).
#'
#'   NOTE: `xs.other` should be compatible with `xs.train`, see Details section
#'   below.
#'
#'   To skip this, use `xs.other=NULL`.
#'
#'   To format `xs.other` correctly, use [alignDatToInfo()].
#' @param ys.other Data frame, the aligned metadata for additional samples, to
#'   which the train Clock should generate predictions. For example, samples you
#'   are considering adding to the training set, or samples from an experimental
#'   or comparison group.
#'
#'   NOTE: `ys.other` should be compatible with `ys.train`, see Details section
#'   below.
#'
#'   To skip this, use `ys.other=NULL`.
#'
#'   To format `ys.other` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys.train` and `ys.other`
#'   containing the outcome variable (typically Age, in years)
#' @param out.csv File name/File path String (must end in ".csv"), the name and
#'   location of the file where the table of coefficients for the Clock will be
#'   saved.  For more information, see Details section below
#' @param output.csv File name/File path String (must end in ".csv"), the name
#'   and location of the file where the output data frame with predicted values
#'   will be saved.  For more information, see Details section below
#'
#'   To skip this, use `output.csv=NULL`.
#' @param out.png File name/File path String (must end in ".png"), the name and
#'   location of the file where the panel plot containing regression diagnostics
#'   and Clock predictions will be saved.  For description of the elastic net
#'   regression diagnostics, see [glmnet::plot.cv.glmnet()] and
#'   [glmnet::plot.glmnet()]
#'
#'   To skip this, use `out.png=NULL`.
#' @param out.png.title String, the title to be used in the panel plot saved to
#'   `out.png`
#' @param PREDVAR String, the name of the NEW appended column in the output
#'   which will contain the predicted outcome variable, the output of the Clock
#'   (same units as `OUTVAR`, and typically DNAm Age)
#' @param RESVAR String, the name of the NEW appended column in the output which
#'   will contain the regression residual of the Clock, the difference of
#'   `PREDVAR` and `OUTVAR` (same units as `OUTVAR`, and typically Age
#'   Acceleration)
#' @param RESinOtherVAR String, the name of the NEW appended column in the
#'   output which will contain the regression residual of the Clock restricted
#'   to the samples in `ys.other`.
#'
#'   To skip this, use `RESinOtherVAR=NULL`.
#' @param ALPHA Numeric, the elasticnet mixing parameter, to be passed into
#'   [glmnet::glmnet()] and [glmnet::cv.glmnet()] (default is `0.5`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; the
#'   option to change it is mostly a formality.
#' @param NFOLD Numeric, the number of folds used for selecting `lambda`, to be
#'   passed into [glmnet::cv.glmnet()] (default is `10`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   will change computation time, at the cost of model fitting optimality.
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable, with up to two additional parameters.  For more
#'   information, see Details section below
#' @param fun_inv Function, the name of an R function that is the mathematical
#'   inverse of `fun_trans`, with the same parameters
#' @param fun_VAR1 String, the name of the column in `ys.train` and `ys.other`
#'   containing the first parameter of `fun_trans`/`fun_inv`, if any (default is
#'   `NULL`, meaning no parameter is required)
#' @param fun_VAR2 String, the name of the column in `ys.train` and `ys.other`
#'   containing the second parameter of `fun_trans`/`fun_inv`, if any (default
#'   is `NULL`, meaning no parameter is required)
#' @param loglambda.seq Numeric Vector, the sequence of `lambda` values, on the
#'   natural log scale, to be evaluated in [glmnet::cv.glmnet()], instead of the
#'   sequence automatically generated (default is `NULL`, which automatically
#'   selects 100 values, evenly spaced on the natural log scale).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   should only be modified in the case of highly heterogeneous data, when the
#'   optimal value of lambda might be lower than the range of values
#'   automatically generated.
#'
#' @details While this function only returns a single data frame, it creates and
#'   saves an additional table and plot directly to new files in the workspace.
#'
#'   This function builds a Clock using elastic net regression (see
#'   [glmnet::glmnet()].  The "optimal value" of the penalty parameter `lamda`
#'   is selected using [glmnet::cv.glmnet()]; specifically, it uses the value
#'   `lambda.1se` (which is the default). This is often referred to as the
#'   "one-standard-error rule" (see Friedman & Hastie, 2010).
#'
#'   The output of this function is a data frame that stacks `ys.train` and
#'   `ys.other`, and then appends four additional new columns. It is expected
#'   that `ys.train` and `ys.other` (as well as `xs.train` and `xs.other`) be
#'   compatible, meaning that they share the same columns and column names, in
#'   the same order.  If `ys.train` and `ys.other` are not compatible, this
#'   function will only keeping column names present in both data frames, prior
#'   to row-binding them (see [rbind2.inner()]).
#'
#'   The first appended column is `"train"`, which indicates whether or not a
#'   sample was part of the training set (`1` means used in training, `0` means
#'   not used in training).  The additional three appended column will be named
#'   based on the values (given by the user) of the arguments `PREDVAR`,
#'   `RESVAR`, and `RESinOtherVAR`.  If `RESinOtherVAR=NULL`, then this column
#'   will not be appended.
#'
#'   The selected set of probes and the coefficients for the Clock are not
#'   returned, but are instead saved in the file given to the argument
#'   `out.csv`.  This table of coefficients contains two columns, named `"var"`
#'   and `"beta"`. The first column, `"var"`, contains the names of the probes
#'   selected by the Clock (using the column names of `xs.train`). The second
#'   column, `"beta"`, contains the regression coefficients of the Clock, which
#'   define the fitted regression model.  The regression model is defined by:
#'   \deqn{Age = x \cdot \beta,} where \eqn{\beta} is the vector of true
#'   coefficients (or weights) and \eqn{x} is the vector of methylation values
#'   of a given sample, including an intercept term.  The fitted regression
#'   model is used to calculate DNAm Age for a given sample, as follows:
#'   \deqn{DNAm Age = x \cdot \hat{\beta},} where \eqn{\hat{\beta}} is the
#'   sparse vector of estimated coefficients.
#'
#'   If you are using a transformation of the outcome variable, the regression
#'   model for the Clock fundamentally changes: \deqn{F(Age) = x \cdot \beta,}
#'   where \eqn{F()} is the transformation of the outcome variable (possibly
#'   with species-specific parameters, which are unwritten).  It is _very
#'   important_ to note that this changes the definition of DNAm Age as well:
#'   \deqn{DNAm Age = F^{-1}(x \cdot \hat{\beta}),} and that the inverse
#'   transformation is now tied to the definition of the Clock.
#'
#'   If you choose not to use one of the transformation functions provided in
#'   this package, then it is up to you, the user, to ensure that `fun_trans`
#'   and `fun_inv` are mathematical inverse of one another.
#'
#' @return A data frame containing metadata and predicted values, created by
#'   stacking `ys.train` and `ys.other`, and then appending predicted values as
#'   new columns.  The names of the new columns are specified by the arguments
#'   `PREDVAR`, `RESVAR`, and `RESinOtherVAR`.
#' @export
saveBuildClock <- function(xs.train, ys.train, xs.other, ys.other, OUTVAR, out.csv, output.csv, out.png, out.png.title, PREDVAR, RESVAR, RESinOtherVAR, ALPHA = 0.5, NFOLD = 10, fun_trans = fun_identity, fun_inv = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL, loglambda.seq = NULL) {
  if (is.null(xs.other) | is.null(ys.other)) {
    ys.other <- NULL
    xs.other <- NULL
  } else if (nrow(xs.other) == 0 | nrow(ys.other) == 0) {
    ys.other <- NULL
    xs.other <- NULL
  }

  rows.keep_train <- which(!is.na(fun_trans(ys.train[, OUTVAR], ys.train[, fun_VAR1], ys.train[, fun_VAR2])))
  if (length(rows.keep_train) < nrow(ys.train)) {
    print(paste(
      nrow(ys.train) - length(rows.keep_train),
      "rows in the training data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    ys.train <- ys.train[rows.keep_train, ]
    xs.train <- xs.train[rows.keep_train, ]
  }

  ys.train.outcome <- ys.train[, OUTVAR]
  ys.other.outcome <- ys.other[, OUTVAR]
  if (is.null(fun_VAR1)) {
    ys.train.funvar1 <- NULL
    ys.other.funvar1 <- NULL
  } else {
    ys.train.funvar1 <- ys.train[, fun_VAR1]
    ys.other.funvar1 <- ys.other[, fun_VAR1]
  }
  if (is.null(fun_VAR2)) {
    ys.train.funvar2 <- NULL
    ys.other.funvar2 <- NULL
  } else {
    ys.train.funvar2 <- ys.train[, fun_VAR2]
    ys.other.funvar2 <- ys.other[, fun_VAR2]
  }

  if (is.null(loglambda.seq)) {
    lambda <- NULL
  } else {
    lambda <- exp(loglambda.seq)
  }
  glmnet.Training.CV <- cv.glmnet(xs.train, fun_trans(ys.train.outcome, ys.train.funvar1, ys.train.funvar2),
                                  nfolds = NFOLD, alpha = ALPHA, family = "gaussian", type.measure = "mse", lambda = lambda
  )
  lambda.glmnet.Training <- glmnet.Training.CV$lambda.1se
  glmnet.Training <- glmnet(xs.train, fun_trans(ys.train.outcome, ys.train.funvar1, ys.train.funvar2),
                            alpha = ALPHA, family = "gaussian", lambda = lambda, nlambda = 100
  )
  print("Debug checkpoint 1")

  glmnet.final <- data.frame(as.matrix(coef(glmnet.Training, s = lambda.glmnet.Training)))
  names(glmnet.final) <- "beta"
  glmnet.final$var <- rownames(glmnet.final)
  glmnet.final <- subset(glmnet.final, select = c(var, beta))
  glmnet.final1 <- subset(glmnet.final, abs(beta) > 0)
  write.table(glmnet.final1, out.csv, sep = ",", row.names = F, quote = F)
  print("Debug checkpoint 2")

  train <- data.frame(ys.train, train = 1)
  ys.train.prediction <- fun_inv(
    as.numeric(predict(glmnet.Training, xs.train, type = "response", s = lambda.glmnet.Training)),
    ys.train.funvar1, ys.train.funvar2
  )
  train[, PREDVAR] <- ys.train.prediction
  attr(train[, PREDVAR], "dimnames") <- NULL
  train[, RESinOtherVAR] <- NA
  attr(train[, RESinOtherVAR], "dimnames") <- NULL
  if (!is.null(xs.other) & !is.null(ys.other)) {
    other <- data.frame(ys.other, train = 0)
    ys.other.prediction <- fun_inv(
      as.numeric(predict(glmnet.Training, xs.other, type = "response", s = lambda.glmnet.Training)),
      ys.other.funvar1, ys.other.funvar2
    )
    other[, PREDVAR] <- ys.other.prediction
    attr(other[, PREDVAR], "dimnames") <- NULL
    other[, RESinOtherVAR] <- NA
    if (length(which(!is.na(ys.other.outcome) & !is.na(ys.other.prediction))) > 2) {
      other[which(!is.na(ys.other.outcome) & !is.na(ys.other.prediction)), RESinOtherVAR] <- residuals(lm(ys.other.prediction ~ ys.other.outcome))
    }
    attr(other[, RESinOtherVAR], "dimnames") <- NULL
    ys.output <- rbind2.inner(train, other)
  } else {
    ys.output <- train
  }
  ys.output[, RESVAR] <- NA
  ys.output[which(!is.na(ys.output[, OUTVAR]) & !is.na(ys.output[, PREDVAR])), RESVAR] <- residuals(lm(ys.output[, PREDVAR] ~ ys.output[, OUTVAR]))
  attr(ys.output[, RESVAR], "dimnames") <- NULL
  print("Debug checkpoint 3")

  if (!is.null(output.csv)) {
    write.table(ys.output, output.csv, sep = ",", row.names = F, quote = F)
  }
  if (!is.null(out.png)) {
    png(out.png, width = 9, height = 10, units = "in", res = 300)
    par(mfrow = c(2, 2))
    redf <- reduct_factor(c(2, 2))
    par(mar = c(5, 5, 5, 2) + 0.1, oma = c(1, 0, 2, 0))
    plot(glmnet.Training.CV,
         main = paste0("Optimal Lambda=", round(lambda.glmnet.Training, digits = 3)),
         cex.main = 1 / redf, cex.lab = 1 / redf, cex.axis = 1 / redf
    )
    # title('A',adj=0,font=2,cex.main=1.4)
    plot(glmnet.Training,
         xvar = "lambda", label = T,
         main = paste(nrow(glmnet.final1), "Probes selected at Optimal Lambda"),
         cex.main = 1 / redf, cex.lab = 1 / redf, cex.axis = 1 / redf
    )
    # title('B',adj=0,font=2,cex.main=1.4)
    PANEL_str <- "Training data"
    N <- length(which(!is.na(ys.train.outcome) & !is.na(ys.train.prediction)))
    if (var(ys.train.outcome, na.rm = T) > 0) {
      COR <- cor(ys.train.prediction, ys.train.outcome,
                 use = "pairwise.complete.obs"
      )
      COR_str <- paste0("cor=", signif(COR, 2))
    } else {
      COR_str <- ""
    }
    plot(
      y = ys.train.prediction, x = ys.train.outcome,
      main = paste0(PANEL_str, " (N=", N, ")"),
      ylab = PREDVAR, xlab = OUTVAR,
      cex.main = 1 / redf, cex.lab = 1 / redf, cex.axis = 1 / redf
    )
    if (var(ys.train.outcome, na.rm = T) > 0 && !is.na(var(ys.train.prediction, na.rm = T))) {
      abline(lm(ys.train.prediction ~ ys.train.outcome))
    }
    abline(0, 1, lty = "dashed")
    title(COR_str, outer = F, line = 0.4, cex.main = 1 / redf)
    # title('C',adj=0,font=2,cex.main=1.4)
    PANEL_str <- "Other data"
    if (!is.null(ys.other)) {
      N <- length(which(!is.na(ys.other.outcome) & !is.na(ys.other.prediction)))
    } else {
      N <- 0
    }
    if (N > 2) {
      if (var(ys.other.outcome, na.rm = T) > 0) {
        COR <- cor(ys.other.prediction, ys.other.outcome,
                   use = "pairwise.complete.obs"
        )
        COR_str <- paste0("cor=", signif(COR, 2))
      } else {
        COR_str <- ""
      }
      plot(
        y = ys.other.prediction, x = ys.other.outcome,
        main = paste0(PANEL_str, " (N=", N, ")"),
        ylab = PREDVAR, xlab = OUTVAR,
        cex.main = 1 / redf, cex.lab = 1 / redf, cex.axis = 1 / redf
      )
      if (var(ys.other.outcome, na.rm = T) > 0 && !is.na(var(ys.other.prediction, na.rm = T))) {
        abline(lm(ys.other.prediction ~ ys.other.outcome))
      }
      abline(0, 1, lty = "dashed")
      title(COR_str, outer = F, line = 0.4, cex.main = 1 / redf)
      # title('D',adj=0,font=2,cex.main=1.4)
    }
    title(paste0(out.png.title, "\n", ncol(xs.train), " Probes selected"), outer = T, line = -1, cex.main = 1 / redf)
    dev.off()
  }
  return(ys.output)
}

#' Build a Set of Independent New Clocks based on a Training Data Set,
#' Stratified by Species
#' @description Fit a set of independent elastic net regression models, trained
#'   by stratifying and using an aligned metadata `ys.train` and an aligned and
#'   normalized methylation data `xs.train`. Elastic net regression results in a
#'   sparse model, meaning that most probes will not be selected in a final
#'   fitted model.
#'
#'   This function should be used if you have a significant number of samples
#'   from multiple different species, and would like to a set of build
#'   single-species Clocks simultaneously.
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Table of all Clock coefficients,} \item{Table of metadata
#'   appended with all Clock predictions,} \item{Panel plot of all Clock
#'   predictions (each panel is one stratum).} }
#'
#'   WARNING: This function calls [glmnet::cv.glmnet()], so the results of this
#'   function are subject to randomness. Users should add line in their R
#'   scripts calling [set.seed()] before calling this function, in order for the
#'   results to be reproducible and consistent
#'
#' @param xs.train Data frame, the aligned and normalized methylation data for
#'   the samples in the training set (rows are samples).
#'
#'   To format `xs.train` correctly, use [alignDatToInfo()].
#' @param ys.train Data frame, the aligned metadata for the samples in the
#'   training set.
#'
#'   To format `ys.train` correctly, use [alignDatToInfo()].
#' @param xs.other Data frame, the aligned and normalized methylation data for
#'   additional samples, to which the train Clock should generate predictions.
#'   For example, samples you are considering adding to the training set, or
#'   samples from an experimental or comparison group (rows are samples).
#'
#'   NOTE: `xs.other` should be compatible with `xs.train`, see Details section
#'   below.
#'
#'   To skip this, use `xs.other=NULL`.
#'
#'   To format `xs.other` correctly, use [alignDatToInfo()].
#' @param ys.other Data frame, the aligned metadata for additional samples, to
#'   which the train Clock should generate predictions. For example, samples you
#'   are considering adding to the training set, or samples from an experimental
#'   or comparison group.
#'
#'   NOTE: `ys.other` should be compatible with `ys.train`, see Details section
#'   below.
#'
#'   To skip this, use `ys.other=NULL`.
#'
#'   To format `ys.other` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys.train` and `ys.other`
#'   containing the outcome variable (typically Age, in years)
#' @param STRATVAR String, the name of the column in `ys.train` and `ys.other`
#'   containing the stratifying variable (typically Species Name), by which to
#'   stratify `ys.train` and build individual Clocks.
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param out.csv File name/File path String (must end in ".csv"), the name and
#'   location of the file where the table of coefficients for the Clock will be
#'   saved.  For more information, see Details section below
#' @param output.csv File name/File path String (must end in ".csv"), the name
#'   and location of the file where the output data frame with predicted values
#'   will be saved.  For more information, see Details section below
#'
#'   To skip this, use `output.csv=NULL`.
#' @param out.png File name/File path String (must end in ".png"), the name and
#'   location of the file where the panel plot containing all Clock predictions
#'   vs. true values (each panel is one stratum) will be saved.  Please note
#'   that this plot will contain all the predictions, from both `ys.train` and
#'   `ys.other`.
#'
#'   Unlike with [saveBuildClock()], no diagnostic plots are generated.
#'
#'   To skip this, use `out.png=NULL`.
#' @param out.png.title String, the title to be used in the panel plot saved to
#'   `out.png`
#' @param PREDVAR String, the name of the NEW appended column in the output
#'   which will contain the predicted outcome variable, the output of the
#'   corresponding Clock for each stratum (same units as `OUTVAR`, and typically
#'   DNAm Age)
#' @param RESVAR String, the name of the NEW appended column in the output which
#'   will contain the regression residual of the corresponding Clock for each
#'   stratum, the difference of `PREDVAR` and `OUTVAR` (same units as `OUTVAR`,
#'   and typically Age Acceleration)
#' @param RESinOtherVAR String, the name of the NEW appended column in the
#'   output which will contain the regression residual of the corresponding
#'   Clock for each stratum, restricted to the samples in `ys.other`.
#'
#'   To skip this, use `RESinOtherVAR=NULL`.
#' @param ALPHA Numeric, the elasticnet mixing parameter, to be passed into
#'   [glmnet::glmnet()] and [glmnet::cv.glmnet()] (default is `0.5`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; the
#'   option to change it is mostly a formality.
#' @param NFOLD Numeric, the number of folds used for selecting `lambda`, to be
#'   passed into [glmnet::cv.glmnet()] (default is `10`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   will change computation time, at the cost of model fitting optimality.
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable, with up to two additional parameters.  For more
#'   information, see [saveBuildClock()]
#' @param fun_inv Function, the name of an R function that is the mathematical
#'   inverse of `fun_trans`, with the same parameters
#' @param fun_VAR1 String, the name of the column in `ys.train` and `ys.other`
#'   containing the first parameter of `fun_trans`/`fun_inv`, if any (default is
#'   `NULL`, meaning no parameter is required)
#' @param fun_VAR2 String, the name of the column in `ys.train` and `ys.other`
#'   containing the second parameter of `fun_trans`/`fun_inv`, if any (default
#'   is `NULL`, meaning no parameter is required)
#' @param COLVAR String, the name of the column in `ys.train` and `ys.other`
#'   containing the coloring variable for the panel plot (default is `NULL`,
#'   uses `COLVAR=STRATVAR`).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param show.original Logical, Should the original full-data plot be shown as
#'   the first panel? (default is `TRUE`)
#' @param loglambda.seq Numeric Vector, the sequence of `lambda` values, on the
#'   natural log scale, to be used in [glmnet::cv.glmnet()], instead of the ones
#'   automatically generated (default is `NULL`, which automatically selects 100
#'   values, evenly spaced on the natural log scale, and independently for each
#'   stratum).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   should only be modified in the case of highly heterogeneous data, when the
#'   optimal value of lambda might be lower than the range of values
#'   automatically generated.
#'
#' @details While this function only returns a single data frame, it creates and
#'   saves an additional table and plot directly to new files in the workspace.
#'
#'   The output of this function is a data frame that stacks `ys.train` and
#'   `ys.other`, and then appends four additional new columns. It is expected
#'   that `ys.train` and `ys.other` (as well as `xs.train` and `xs.other`) be
#'   compatible, meaning that they share the same columns and column names, in
#'   the same order.  If `ys.train` and `ys.other` are not compatible, this
#'   function will only keeping column names present in both data frames, prior
#'   to row-binding them (see [rbind2.inner()]).
#'
#'   The first appended column is `"train"`, which indicates whether or not a
#'   sample was part of the training set (`1` means used in training, `0` means
#'   not used in training).  The additional three appended column will be named
#'   based on the values (given by the user) of the arguments `PREDVAR`,
#'   `RESVAR`, and `RESinOtherVAR`.  If `RESinOtherVAR=NULL`, then this column
#'   will not be appended.
#'
#'   The selected set of probes and the coefficients for all of the Clocks are
#'   not returned, but are instead saved together in the file given to the
#'   argument `out.csv`.  This table of coefficients contains \eqn{S+1} columns,
#'   named `"var"` and `"beta.<level>"`, where \eqn{S} refers to `S ==
#'   length(levels(ys.train[,SPECVAR]))`. The first column, `"var"`, contains
#'   the names of the probes selected by at least one of the Clocks (using the
#'   column names of `xs.train`). The remaining \eqn{S} columns,
#'   `"beta.<level>"`, each contain the regression coefficients of the Clock
#'   (corresponding to that stratum), which define the fitted regression model.
#'
#'   For all other details related to building Clocks, see Details section in
#'   [saveBuildClock()].
#'
#' @return A data frame containing metadata and predicted values, created by
#'   stacking `ys.train` and `ys.other`, and then appending predicted values as
#'   new columns.  The names of the new columns are specified by the arguments
#'   `PREDVAR`, `RESVAR`, and `RESinOtherVAR`.
#' @export
saveBuildClockStrat <- function(xs.train, ys.train, xs.other, ys.other, OUTVAR, STRATVAR, out.csv, output.csv, out.png, out.png.title, PREDVAR, RESVAR, RESinOtherVAR, ALPHA = 0.5, NFOLD = 10, fun_trans = fun_identity, fun_inv = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL, COLVAR = NULL, show.original = T, loglambda.seq = NULL) {
  if (is.null(STRATVAR)) {
    stop("STRATVAR cannot be NULL")
  }
  if (!is.factor(ys.train[, STRATVAR])) {
    stop("STRATVAR must correspond to a factor-type column")
  }
  if (is.null(COLVAR)) {
    COLVAR <- STRATVAR
  }

  ys.output <- data.frame()
  glmnet.final <- data.frame(var = colnames(xs.train))
  out.strat.csv <- "temp_saveBuildClockStrat.csv" # temporary file where coefficients are saved, at every iteration
  for (strat.num in 1:length(levels(ys.train[, STRATVAR]))) {
    strat.name <- levels(ys.train[, STRATVAR])[strat.num]
    indcs.train <- which(as.numeric(ys.train[, STRATVAR]) == strat.num)
    indcs.other <- which(as.character(ys.other[, STRATVAR]) == strat.name)
    print(paste("Debug checkpoint: Stratum", strat.name))
    xs.train.strat <- xs.train[indcs.train, ]
    ys.train.strat <- ys.train[indcs.train, ] %>%
      dplyr::mutate(train = 1)
    if (length(unique(ys.train[indcs.train, OUTVAR])) <= 2) {
      stop(paste0("Stratum \"", strat.name, "\" could not be modelled (not enough samples)"))
    }
    if (!is.null(xs.other) & !is.null(ys.other)) {
      xs.other.strat <- xs.other[indcs.other, ]
      ys.other.strat <- ys.other[indcs.other, ] %>%
        dplyr::mutate(train = 0)
      if (nrow(ys.other.strat) == 1) {
        xs.other.strat <- t(as.matrix(xs.other.strat)) # correcting format of xs.other.strat
      }
    }
    ys.output.strat <- saveBuildClock(xs.train.strat, ys.train.strat, xs.other.strat, ys.other.strat,
                                      OUTVAR,
                                      out.csv = out.strat.csv, output.csv = NULL, out.png = NULL, out.png.title = NULL, PREDVAR = PREDVAR, RESVAR = RESVAR, RESinOtherVAR = RESinOtherVAR,
                                      ALPHA = ALPHA, NFOLD = NFOLD, fun_trans = fun_trans, fun_inv = fun_inv, fun_VAR1 = fun_VAR1, fun_VAR2 = fun_VAR2, loglambda.seq = loglambda.seq
    )
    ys.output <- rbind(ys.output, ys.output.strat)
    glmnet.strat <- read.csv(out.strat.csv)
    file.remove(out.strat.csv)
    colnames(glmnet.strat) <- c("var", paste0("beta.", snakecase::to_upper_camel_case(strat.name)))
    glmnet.final <- base::merge(glmnet.final, glmnet.strat, "var", all = T, sort = F)
  }
  num_shared <- NULL
  glmnet.final$num_shared <- rowSums(sapply(as.data.frame(!is.na(glmnet.final)), as.numeric)) - 1
  glmnet.final <- dplyr::filter(glmnet.final, num_shared >= 1)
  write.table(glmnet.final, out.csv, sep = ",", row.names = F, quote = F)

  ys.output[, STRATVAR] <- factor(ys.output[, STRATVAR])
  if (!is.null(output.csv)) {
    write.table(ys.output, output.csv, sep = ",", row.names = F, quote = F)
  }
  if (!is.null(out.png)) {
    TITLE_str <- paste0(out.png.title, "\n")
    saveValidationPanelPlot(ys.output, OUTVAR, PREDVAR, PANELVAR = STRATVAR, out.png, TITLE_str, COLVAR = COLVAR, show.original = show.original)
  }

  return(ys.output)
}

#' Apply a Clock to Methylation Data
#' @description Applies a previously built Clock to normalized methylation data
#'   `xs.new`. Ensure that the set of probes used to define the Clock are
#'   present within the column names of `xs.new` (in order words, that the
#'   methylation array used to build the Clock is the same array used to
#'   generate `xs.new`)
#'
#'   It is __very important__ to note that if the Clock being provided was built
#'   using a transformation of the outcome variable (e.g. an age
#'   transformation), then you __must__ provide the inverse transformation in
#'   order to properly generate predicted values.
#'
#' @param in.valbeta 2-column Matrix or Data frame, the table of coefficients
#'   for the built Clock (column 1=probe, column 2=coefficient)
#' @param xs.new Data frame, the aligned and normalized methylation data for the
#'   samples in the new, independent set (rows are samples).
#'
#'   To format `xs.new` correctly, use [alignDatToInfo()].
#' @param fun_inv Function, the name of an R function that inverse transforms
#'   the weighted sum of methylation values, with up to two additional
#'   parameters.  This function, if it is present, is part of the definition of
#'   the Clock being applied.  For more information, see [saveBuildClock()]
#' @param fun_VAR1_val Numeric OR Numeric vector, the value of the first
#'   parameter of `fun_inv`, if any, for each row of `xs.new`(default is `NA`,
#'   meaning no parameter is used)
#' @param fun_VAR2_val Numeric OR Numeric vector, the value of the second
#'   parameter of `fun_inv`, if any, for each row of `xs.new`(default is `NA`,
#'   meaning no parameter is used)
#'
#' @details The output of this function is a vector containing the predicted
#'   outcome variable, the output of the Clock (e.g., DNAm Age)
#'
#'   For all details related to building Clocks, see Details section in
#'   [saveBuildClock()].
#'
#'   For efficiently applying all published Clocks, and for information on using
#'   these Clocks, see Details sections in [predictAge()].
#'
#' @return A vector containing predicted values, where each entry corresponds to
#'   each row of `xs.new`.
#' @export
predictClockSimple <- function(in.valbeta, xs.new, fun_inv = fun_identity, fun_VAR1_val = NA, fun_VAR2_val = NA) {
  if (ncol(in.valbeta) != 2) {
    stop("in.valbeta doesn't follow correct format")
  }

  ones.column <- data.frame(V1 = rep(1, nrow(xs.new)))
  colnames(ones.column) <- as.character(in.valbeta[1, 1])

  xs.new_complete <- t(na.omit(t(xs.new))) # remove data columns (probes) that have missing values
  if (ncol(xs.new) > ncol(xs.new_complete)) {
    warning(paste0(ncol(xs.new) - ncol(xs.new_complete), " columns of xs.new removed due to missing values"))
  }

  in.valbeta_trimmed <- in.valbeta[sort(c(1, which(as.character(in.valbeta[, 1]) %in% colnames(xs.new_complete)))), ]
  if (nrow(in.valbeta_trimmed) - 1 == 0) {
    warning("methylation data (xs argument) is missing all clock coefficients in columns, or has missing data in all corresponding columns")
    return(rep(NA, nrow(xs.new)))
  }
  num_beta.not_in_New <- nrow(in.valbeta) - nrow(in.valbeta_trimmed)
  if (num_beta.not_in_New > 0) {
    warning(paste0(nrow(in.valbeta_trimmed) - 1, " clock probes found in xs.new, ", num_beta.not_in_New, " clock probes not found or have missing values in xs.new"))
  }
  xs.new_trimmed <- cbind(ones.column, xs.new_complete)
  xs.new_trimmed <- xs.new_trimmed[, c(1, which(colnames(xs.new_trimmed) %in% as.character(in.valbeta_trimmed[, 1])))]
  xs.new_trimmed <- dplyr::select(xs.new_trimmed, as.character(in.valbeta_trimmed[, 1])) # sort xs.new to match in.valbeta
  ys.new.prediction.raw <- as.vector(as.matrix(xs.new_trimmed) %*% in.valbeta_trimmed[, 2])
  if (length(ys.new.prediction.raw) > 0) {
    ys.new.prediction <- fun_inv(ys.new.prediction.raw, fun_VAR1_val, fun_VAR2_val)
  } else {
    ys.new.prediction <- ys.new.prediction.raw
  }

  return(ys.new.prediction)
}

#' Apply a Clock to a New Data Set and Generate Predicted Values
#' @description Applies a previously built Clock to a given data set (an aligned
#'   metadata `ys.new` and an aligned and normalized methylation data `xs.new`).
#'   Ensure that the set of probes used to define the Clock are present within
#'   the column names of `xs.new` (in order words, that the methylation array
#'   used to build the Clock is the same array used to generate `xs.new`)
#'
#'   It is __very important__ to note that if the Clock being provided was built
#'   using a transformation of the outcome variable (e.g. an age
#'   transformation), then you __must__ provide the inverse transformation in
#'   order to properly generate predicted values.
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Table of metadata appended with all Clock predictions,}
#'   \item{Plot of Clock predictions.} }
#'
#' @param in.valbeta 2-column Matrix or Data frame, the table of coefficients
#'   for the built Clock (column 1=probe, column 2=coefficient)
#' @param xs.new Data frame, the aligned and normalized methylation data for the
#'   samples in the new, independent set (rows are samples).
#'
#'   To format `xs.new` correctly, use [alignDatToInfo()].
#' @param ys.new Data frame, the aligned metadata for the samples in the new,
#'   independent set.
#'
#'   To format `ys.new` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys.new` containing the
#'   outcome variable (typically Age, in years)
#' @param output.csv File name/File path String (must end in ".csv"), the name
#'   and location of the file where the output data frame with predicted values
#'   will be saved.  For more information, see Details section below
#'
#'   To skip this, use `output.csv=NULL`.
#' @param out.png File name/File path String (must end in ".png"), the name and
#'   location of the file where the plot containing Clock predictions vs. true
#'   values will be saved
#'
#'   To skip this, use `out.png=NULL`.
#' @param out.png.title String, the title to be used in the plot saved to
#'   `out.png`
#' @param PREDVAR String, the name of the NEW appended column in the output
#'   which will contain the predicted outcome variable, the output of the Clock
#'   (same units as `OUTVAR`, and typically DNAm Age)
#' @param RESVAR String, the name of the NEW appended column in the output which
#'   will contain the regression residual of the Clock, the difference of
#'   `PREDVAR` and `OUTVAR` (same units as `OUTVAR`, and typically Age
#'   Acceleration)
#' @param fun_inv Function, the name of an R function that inverse transforms
#'   the weighted sum of methylation values, with up to two additional
#'   parameters.  This function, if it is present, is part of the definition of
#'   the Clock being applied.  For more information, see [saveBuildClock()]
#' @param fun_VAR1 String, the name of the column in `ys.new` containing the
#'   first parameter of `fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param fun_VAR2 String, the name of the column in `ys.new` containing the
#'   second parameter of `fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param COLVAR String, the name of the column in `ys.new` containing the
#'   coloring variable for the plot (default is `NULL`, does not color points).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param show.legend Logical, Should the plot include a legend for `COLVAR`?
#'   (default is `TRUE`)
#' @param oma.right Numeric, the size of the right outer margin for the plot, in
#'   lines of text (default is `9`).  Increase this value if the legend is being
#'   truncated (the image width will be automatically adjusted).
#' @param square.axes Logical, Should the axis limits for the x-axis and y-axis
#'   be forced to be equal? (default is `TRUE`, otherwise axis limits are
#'   determined independently)
#'
#' @details While this function only returns a single data frame, it creates and
#'   saves an additional plot directly to a new file in the workspace.
#'
#'   The output of this function is a data frame that copies `ys.new` and
#'   appends two additional new columns.
#'
#'   The two appended column will be named based on the values (given by the
#'   user) of the arguments `PREDVAR` and `RESVAR`.
#'
#'   For all details related to building Clocks, see Details section in
#'   [saveBuildClock()].
#'
#'   For efficiently applying all published Clocks, and for information on using
#'   these Clocks, see Details sections in [predictAge()].
#'
#' @return A data frame containing metadata and predicted values, created by
#'   copying `ys.new` and appending predicted values as new columns.  The names
#'   of the new columns are specified by the arguments `PREDVAR` and `RESVAR`.
#' @export
saveApplyClock <- function(in.valbeta, xs.new, ys.new, OUTVAR, output.csv, out.png, out.png.title, PREDVAR, RESVAR, fun_inv = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL, COLVAR = NULL, show.legend = T, oma.right = 9, square.axes = T) {
  if (is.null(ys.new)) {
    stop("ys.new cannot be NULL")
  }
  if (ncol(in.valbeta) != 2) {
    stop("in.valbeta doesn't follow correct format")
  }
  ys.new.outcome <- ys.new[, OUTVAR]
  if (is.null(fun_VAR1)) {
    ys.new.funvar1 <- NA
  } else {
    ys.new.funvar1 <- ys.new[, fun_VAR1]
  }
  if (is.null(fun_VAR2)) {
    ys.new.funvar2 <- NA
  } else {
    ys.new.funvar2 <- ys.new[, fun_VAR2]
  }

  ys.new.prediction <- predictClockSimple(in.valbeta, xs.new,
                                          fun_inv = fun_inv,
                                          fun_VAR1_val = ys.new.funvar1, fun_VAR2_val = ys.new.funvar2
  )
  in.valbeta_trimmed <- in.valbeta[sort(c(1, which(as.character(in.valbeta[, 1]) %in% colnames(xs.new)))), ]
  num_beta.not_in_New <- nrow(in.valbeta) - nrow(in.valbeta_trimmed)

  ys.output <- ys.new
  ys.output[, PREDVAR] <- ys.new.prediction
  attr(ys.output[, PREDVAR], "dimnames") <- NULL
  ys.output[, RESVAR] <- NA
  if (length(which(!is.na(ys.new.outcome) & !is.na(ys.new.prediction))) > 2) {
    ys.output[which(!is.na(ys.new.outcome) & !is.na(ys.new.prediction)), RESVAR] <- residuals(lm(ys.new.prediction ~ ys.new.outcome))
    attr(ys.output[, RESVAR], "dimnames") <- NULL
  }

  if (!is.null(output.csv)) {
    write.table(ys.output, output.csv, sep = ",", row.names = F, quote = F)
  }
  if (!is.null(out.png) & length(which(!is.na(ys.new.outcome) & !is.na(ys.new.prediction))) > 0) {
    TITLE_str <- paste0(out.png.title, "\n", ncol(xs.new) - num_beta.not_in_New, " probes used, ", num_beta.not_in_New, " probes unused")
    saveValidationPlot(ys.output, OUTVAR, PREDVAR, COLVAR, out.png, TITLE_str, show.legend = show.legend, oma.right = oma.right, square.axes = square.axes)
  }
  if (!is.null(out.png) & length(which(!is.na(ys.new.outcome) & !is.na(ys.new.prediction))) == 0) {
    print("WARNING: Unable to plot, all values of outcome or prediction are missing")
  }

  return(ys.output)
}

#' Automatically Apply All Published Clocks to a New Data Set and Generate
#' Predicted Values
#' @description Applies all previously built & published Clock that are
#'   potentially applicable (based on tissue type(s) and species) to a given
#'   data set (an aligned metadata `ys.new` and an aligned and normalized
#'   methylation data `xs.new`). Ensure that the methylation array used to
#'   generate `xs.new` is the same array used to build all of the published
#'   Clocks (in other words, the Horvath Mammalian Chip).
#'
#'   It is __very important__ to note that if the tissue(s) and species name(s)
#'   being provided in the arguments match those used to generate the
#'   methylation data being provided, because Clocks are __only designed__ to be
#'   accurate with the set of tissues and set of species on which they were
#'   trained.
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Table of metadata appended with all predictions, using all
#'   applicable and published Clocks.} }
#'
#' @param xs.new Data frame, the aligned and normalized methylation data for the
#'   samples in the new, independent set (rows are samples).
#'
#'   To format `xs.new` correctly, use [alignDatToInfo()].
#' @param ys.new Data frame, the aligned metadata for the samples in the new,
#'   independent set
#'
#'   NOTE: This can be a data frame with only column, e.g., sample IDs.
#'
#'   To format `ys.new` correctly, use [alignDatToInfo()].
#' @param tissue.names String OR String Vector, the tissue(s) from which the
#'   samples in `xs.new` were generated.
#'
#'   NOTE: These tissue names must match what are encoded in the internal
#'   database of existing clocks; see [getClockDatabase()]
#'
#'   To ignore tissue type compatibility, use `tissue.names="ALL"`.
#' @param species.name String, the species latin name for the species from which
#'   the samples in `xs.new` were generated.
#'
#'   NOTE: This species latin name must match what is encoded in the internal
#'   database of existing clocks; see [getClockDatabase()].  For species not in
#'   the database, the universal clock will still be applied, and the species
#'   latin name must match what is encoded in the internal anAge table; see
#'   [getAnAgeTable()]
#'
#'   To ignore species compatibility, use `species.name="ALL"`.
#'
#' @details The output of this function is a data frame that copies `ys.new` and
#'   appends one or more additional new columns.
#'
#'   The appended columns will be named (automatically) to specify each clock
#'   being applied.
#'
#'   For all coefficient files and age transformations for all published Clocks,
#'   see the package's [GitHub
#'   repository](https://github.com/jazoller96/mammalian-methyl-clocks).
#'
#' @return A data frame containing metadata and all predicted values, created by
#'   copying `ys.new` and appending predicted values as new columns.  The names
#'   of the new columns are generated automatically to describe which clock is
#'   being used.
#' @export
predictAge <- function(xs.new, ys.new, tissue.names, species.name) {
  if (is.null(ys.new)) {
    stop("ys.new cannot be NULL")
  }
  if (length(species.name) >= 2) {
    warning("'species.name' has length > 1, so only the first element will be used")
    species.name <- species.name[1]
  }
  # DELETE LATER (USED FOR CODE TESTING):
  # devtools::load_all()
  # tissue.names = c("Blood","Ear")
  # species.name = "Ovis aries"
  # i=7
  if ("ALL" %in% tissue.names) {
    rows_match <- unique(unlist(lapply(c(species.name, "ALL"), grep, clocks_metadatabase$SpeciesNames)))
    if ("ALL" == species.name) {
      stop("Please select one species or at least one tissue type")
    }
  } else if ("ALL" == species.name) {
    rows_match <- unique(unlist(lapply(c(tissue.names, "ALL"), grep, clocks_metadatabase$Tissues)))
  } else {
    rows_match <- intersect(
      unique(unlist(lapply(c(tissue.names, "ALL"), grep, clocks_metadatabase$Tissues))),
      unique(unlist(lapply(c(species.name, "ALL"), grep, clocks_metadatabase$SpeciesNames)))
    )
  }
  if (length(rows_match) == 0) {
    stop("No tissue or species matches found")
  }
  # DELETE LATER (USED FOR CODE TESTING):
  # clocks_metadatabase[rows_match,]
  # clocks_metadatabase[rows_match,"Tissues"]
  # clocks_metadatabase[rows_match,"SpeciesNames"]
  ys.output <- ys.new
  for (i in 1:length(rows_match)) {
    clock_coefficients <- clock_coefficients_list[[match(
      clocks_metadatabase$CoefficientsName[rows_match[i]],
      names(clock_coefficients_list)
    )]]
    in.valbeta <- na.omit(clock_coefficients[, 1 + c(0, clocks_metadatabase$CoefficientsColumnNum[rows_match[i]])])
    rownames(in.valbeta) <- NULL
    attr(in.valbeta, "na.action") <- NULL
    PREDVAR_i <- unlist(strsplit(colnames(in.valbeta)[2], "Coef."))[2]
    if (!grepl("Relative", PREDVAR_i)) {
      PREDVAR_i <- paste0("DNAmAge.", PREDVAR_i)
    } else {
      PREDVAR_i <- paste0("DNAmRelAge.", PREDVAR_i)
    }
    NAME_fun_inv <- clocks_metadatabase$InverseTransform[rows_match[i]]
    fun_inv <- get(NAME_fun_inv)

    clock_species_vec <- unlist(strsplit(clocks_metadatabase$SpeciesNames[rows_match[i]], ";"))
    if (any(grepl(species.name, clock_species_vec))) {
      index_species_match <- grep(species.name, clock_species_vec)
      fun_VAR1_val <- as.numeric(unlist(strsplit(as.character(clocks_metadatabase$fun_VAR1[rows_match[i]]), ";")))[index_species_match]
      fun_VAR2_val <- as.numeric(unlist(strsplit(as.character(clocks_metadatabase$fun_VAR2[rows_match[i]]), ";")))[index_species_match]
    } else {
      # captures edge case, where clock_species_vec == "ALL"
      anage_row_number <- which(species.name == anAge_table$SpeciesLatinName)
      anage_column_name.fun_VAR1 <- clocks_metadatabase$fun_VAR1[rows_match[i]]
      anage_column_name.fun_VAR2 <- clocks_metadatabase$fun_VAR2[rows_match[i]]
      # valid options for clocks_metadatabase$fun_VAR1[rows_match[i]], clocks_metadatabase$fun_VAR2[rows_match[i]]:
      # - "Gestation.Incubation..days." (will be converted to years)
      # - "averagedMaturity.yrs"
      # - "maxAgeCaesar"
      if (species.name %in% anAge_table$SpeciesLatinName) {
        # if species is IN anAge
        if (!is.na(anage_column_name.fun_VAR1) && anage_column_name.fun_VAR1 == "Gestation.Incubation..days.") {
          fun_VAR1_val <- anAge_table[anage_row_number, anage_column_name.fun_VAR1] / 365
        } else {
          fun_VAR1_val <- anAge_table[anage_row_number, anage_column_name.fun_VAR1]
        }
        if (!is.na(anage_column_name.fun_VAR2) && anage_column_name.fun_VAR2 == "Gestation.Incubation..days.") {
          fun_VAR2_val <- anAge_table[anage_row_number, anage_column_name.fun_VAR2] / 365
        } else {
          fun_VAR2_val <- anAge_table[anage_row_number, anage_column_name.fun_VAR2]
        }
      } else {
        # if species is NOT IN anAge
        fun_VAR1_val <- NA
        fun_VAR2_val <- NA
        warning("Species not in anAge database")
      }
    }

    ys.new.prediction_i <- predictClockSimple(in.valbeta, xs.new,
                                              fun_inv = fun_inv,
                                              fun_VAR1_val = fun_VAR1_val, fun_VAR2_val = fun_VAR2_val
    )
    if (length(ys.new.prediction_i) > 0) {
      ys.output[, PREDVAR_i] <- ys.new.prediction_i
      attr(ys.output[, PREDVAR_i], "dimnames") <- NULL
    }
  }

  return(ys.output)
}
#' @export
#' @rdname predictAge
getClockDatabase <- function() {
  return(clocks_metadatabase)
}
#' @export
#' @rdname predictAge
getAnAgeTable <- function() {
  return(anAge_table)
}

#' Perform Epigenome-wide Association Study on Outcome Variable
#' @description Performs an epigenome-wide association study (EWAS) on the
#'   outcome variable.
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Table of EWAS results.} }
#'
#' @param xs Data frame, the aligned and normalized methylation data for the
#'   samples used to build a Clock (rows are samples).
#'
#'   To format `xs` correctly, use [alignDatToInfo()].
#' @param ys Data frame, the aligned metadata for the samples used to build a
#'   Clock.
#'
#'   To format `ys` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys` containing the outcome
#'   variable (typically Age, in years, but can be binary as well)
#' @param ewas.csv File name/File path String (must end in ".csv"), the name and
#'   location of the file where the output data frame with the EWAS scores and
#'   significant values will be saved.  For more information, see Details
#'   section below
#'
#'   To skip this, use `ewas.csv=NULL`.
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable prior to calculating correlations with every probe, with
#'   up to two additional parameters.  If a transformation function was used to
#'   build a corresponding Clock, then the same function should be provided
#'   here.  For more information, see [saveBuildClock()]
#' @param fun_VAR1 String, the name of the column in `ys` containing the first
#'   parameter of `fun_trans`, if any (default is `NULL`, meaning no parameter
#'   is required)
#' @param fun_VAR2 String, the name of the column in `ys` containing the second
#'   parameter of `fun_trans`, if any (default is `NULL`, meaning no parameter
#'   is required)
#'
#' @details In this function, the outcome variable is first transformed, using
#'   `fun_trans`, if such a function is provided.  Then, with these transformed
#'   outcome values as 'traits', and along with the methylation data, the EWAS
#'   is performed.  For details about the computations, see
#'   [WGCNA::standardScreeningNumericTrait()] (or
#'   [WGCNA::standardScreeningBinaryTrait()]).
#'
#' @return A data frame containing the results of the EWAS.  For an explanation
#'   of each column in the output, see [WGCNA::standardScreeningNumericTrait()]
#'   (or [WGCNA::standardScreeningBinaryTrait()]).
#' @export
saveEWAS <- function(xs, ys, OUTVAR, ewas.csv, fun_trans = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL) {
  rows.keep <- which(!is.na(fun_trans(ys[, OUTVAR], ys[, fun_VAR1], ys[, fun_VAR2])))
  if (length(rows.keep) < nrow(ys)) {
    print(paste(
      nrow(ys) - length(rows.keep),
      "rows in the data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    ys <- ys[rows.keep, ]
    xs <- xs[rows.keep, ]
  }

  ys.outcome <- ys[, OUTVAR]
  if (is.null(fun_VAR1)) {
    ys.funvar1 <- NULL
  } else {
    ys.funvar1 <- ys[, fun_VAR1]
  }
  if (is.null(fun_VAR2)) {
    ys.funvar2 <- NULL
  } else {
    ys.funvar2 <- ys[, fun_VAR2]
  }

  if (length(unique(ys.outcome)) >= 3) {
    ewas.table <- standardScreeningNumericTrait(xs, fun_trans(ys.outcome, ys.funvar1, ys.funvar2),
                                                qValues = T, areaUnderROC = F
    )
  } else {
    ewas.table <- standardScreeningBinaryTrait(xs, fun_trans(ys.outcome, ys.funvar1, ys.funvar2),
                                               qValues = T, getAreaUnderROC = F
    )
  }

  if (!is.null(ewas.csv)) {
    write.table(ewas.table, ewas.csv, sep = ",", row.names = F, quote = F)
  }

  return(ewas.table)
}

#' Perform Meta Epigenome-wide Association Study on Outcome Variable, by
#' Secondary Variable
#' @description Performs a meta epigenome-wide association study (meta-EWAS) on
#'   the outcome variable, by first stratifying the data by secondary
#'   categorical variable and performing an EWAS within each stratum.  The
#'   results are then aggregated via Stouffer's method to calculate a single
#'   index.
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Aggregate Table of meta-EWAS results,} \item{Multiple
#'   Tables of stratified EWAS results (one for each stratum),} \item{Plot of
#'   Clock predictions.} }
#'
#' @param xs Data frame, the aligned and normalized methylation data for the
#'   samples used to build a Clock (rows are samples).
#'
#'   To format `xs` correctly, use [alignDatToInfo()].
#' @param ys Data frame, the aligned metadata for the samples used to build a
#'   Clock.
#'
#'   To format `ys` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys` containing the outcome
#'   variable (typically Age, in years, but can be binary as well)
#' @param STRATVAR String, the name of the column in `ys` containing the
#'   stratifying variable (typically Tissue Type), by which to stratify `ys` and
#'   calculate independent z-scores.
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param ewas.csv.PREFIX File name/File path String PREFIX (meaning a file name
#'   or file path without the '.csv' at the end), the name and location of the
#'   files where the meta-EWAS output table, and each of the strata EWAS output
#'   tables, will be saved
#'
#'   To skip this, use `ewas.csv.PREFIX=NULL`.
#' @param ewas.png File name/File path String (must end in ".png"), the name and
#'   location of the file where the panel plot containing pairwise strata
#'   z-scores of the probes will be saved
#'
#'   To skip this, use `ewas.png=NULL`.
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable prior to calculating correlations with every probe, with
#'   up to two additional parameters.  If a transformation function was used to
#'   build a corresponding Clock, then the same function should be provided
#'   here.  For more information, see [saveBuildClock()]
#' @param fun_VAR1 String, the name of the column in `ys` containing the first
#'   parameter of `fun_trans`, if any (default is `NULL`, meaning no parameter
#'   is required)
#' @param fun_VAR2 String, the name of the column in `ys` containing the second
#'   parameter of `fun_trans`, if any (default is `NULL`, meaning no parameter
#'   is required)
#' @param ewas.png.size Numeric, the width and height of the plot, in inches (at
#'   600 ppi) (default is `NULL`, automatically calculates based on number of
#'   strata)
#'
#' @details While this function only returns a single data frame, it creates and
#'   saves an additional plot, and multiple tables, directly to a new file in
#'   the workspace.
#'
#'   The output of this function is a data frame that contains the results of
#'   the meta-EWAS.  The set of tables that are saved as files contain the
#'   results of each individual EWAS, with a suffix added with the name of the
#'   stratum value.
#'
#'   The panel plot that is generated is a pairs plot of all of the strata
#'   z-score columns, where the upper-right plots are pairwise scatter plots,
#'   the lower-left "plots" display the pairwise correlations of each scatter
#'   plot, and the diagonal contains the name of the stratum value corresponding
#'   to every row and column.
#'
#'   For details about performing regular EWAS, see [saveEWAS()].
#'
#' @return A data frame containing the following components:
#'   \itemize{ \item{ID}{The ID/name of the probe}
#'   \item{Z.<stratum>}{(Multiple columns) The score of the probe within each
#'   stratum, calculated in [saveEWAS()]} \item{metaZ}{The aggregate score of
#'   the probe across all strata, calculated via Stouffer's method}
#'   \item{metaPvalue}{The unadjusted p-value coresponding to `metaZ`} }
#' @export
saveMetaEWAS <- function(xs, ys, OUTVAR, STRATVAR, ewas.csv.PREFIX, ewas.png, fun_trans = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL, ewas.png.size = NULL) {
  if (is.null(STRATVAR)) {
    stop("STRATVAR cannot be NULL")
  }
  if (!is.factor(ys[, STRATVAR])) {
    stop("STRATVAR must correspond to a factor-type column")
  }

  rows.keep <- which(!is.na(fun_trans(ys[, OUTVAR], ys[, fun_VAR1], ys[, fun_VAR2])))
  if (length(rows.keep) < nrow(ys)) {
    print(paste(
      nrow(ys) - length(rows.keep),
      "rows in the data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    print("WARNING: Because of this, levels of STRATVAR may have been removed and reordered")
    ys <- ys[rows.keep, ]
    xs <- xs[rows.keep, ]
    ys[, STRATVAR] <- factor(ys[, STRATVAR])
    xs[, STRATVAR] <- factor(xs[, STRATVAR])
  }

  ys.outcome <- ys[, OUTVAR]
  if (is.null(fun_VAR1)) {
    ys.funvar1 <- NULL
  } else {
    ys.funvar1 <- ys[, fun_VAR1]
  }
  if (is.null(fun_VAR2)) {
    ys.funvar2 <- NULL
  } else {
    ys.funvar2 <- ys[, fun_VAR2]
  }

  ewas.table.list <- vector("list", length(levels(ys[, STRATVAR])))
  ewas.Z.list <- vector("list", length(levels(ys[, STRATVAR])))
  strat.names <- vector("character", 0)
  for (strat.num in 1:length(levels(ys[, STRATVAR]))) {
    indcs <- which(as.numeric(ys[, STRATVAR]) == strat.num)
    if (length(unique(ys.outcome)) >= 3) {
      if (length(indcs) >= 3 && !is.na(var(ys.outcome[indcs], na.rm = T)) && var(ys.outcome[indcs], na.rm = T) > 0) {
        ewas.table.list[[strat.num]] <- standardScreeningNumericTrait(xs[indcs, ], fun_trans(ys.outcome[indcs], ys.funvar1[indcs], ys.funvar2[indcs]),
                                                                      areaUnderROC = F
        )
        if (!is.null(ewas.csv.PREFIX)) {
          ewas.csv <- paste0(ewas.csv.PREFIX, "_", levels(ys[, STRATVAR])[strat.num], ".csv")
          write.table(ewas.table.list[[strat.num]], ewas.csv, sep = ",", row.names = F, quote = F)
        }
        ewas.Z.list[[strat.num]] <- standardScreeningNumericTrait(xs[indcs, ], fun_trans(ys.outcome[indcs], ys.funvar1[indcs], ys.funvar2[indcs]),
                                                                  areaUnderROC = F
        )$Z
        strat.names <- c(strat.names, paste0("Z.", levels(ys[, STRATVAR])[strat.num]))
      } else {
        ewas.table.list[[strat.num]] <- NULL
        ewas.Z.list[[strat.num]] <- NULL
      }
    } else {
      if (length(indcs) >= 3 && unique(ys.outcome[indcs]) == 2) {
        ewas.table.list[[strat.num]] <- standardScreeningBinaryTrait(xs[indcs, ], fun_trans(ys.outcome[indcs], ys.funvar1[indcs], ys.funvar2[indcs]),
                                                                     getAreaUnderROC = F
        )
        if (!is.null(ewas.csv.PREFIX)) {
          ewas.csv <- paste0(ewas.csv.PREFIX, "_", levels(ys[, STRATVAR])[strat.num], ".csv")
          write.table(ewas.table.list[[strat.num]], ewas.csv, sep = ",", row.names = F, quote = F)
        }
        ewas.Z.list[[strat.num]] <- standardScreeningBinaryTrait(xs[indcs, ], fun_trans(ys.outcome[indcs], ys.funvar1[indcs], ys.funvar2[indcs]),
                                                                 getAreaUnderROC = F
        )$Z
        strat.names <- c(strat.names, paste0("Z.", levels(ys[, STRATVAR])[strat.num]))
      } else {
        ewas.table.list[[strat.num]] <- NULL
        ewas.Z.list[[strat.num]] <- NULL
      }
    }
  }
  ewas.meta.table <- as.data.frame(do.call(cbind, ewas.Z.list))
  colnames(ewas.meta.table) <- strat.names
  ewas.meta.table$metaZ <- rowSums(ewas.meta.table) / sqrt(ncol(ewas.meta.table))
  ewas.meta.table$metaPvalue <- 2 * (1 - pnorm(abs(ewas.meta.table$metaZ)))
  ewas.meta.table <- cbind(ID = colnames(xs), ewas.meta.table)
  if (!is.null(ewas.csv.PREFIX)) {
    ewas.meta.csv <- paste0(ewas.csv.PREFIX, ".csv")
    write.table(ewas.meta.table, ewas.meta.csv, sep = ",", row.names = F, quote = F)
  }

  if (is.null(ewas.png.size)) {
    ewas.png.size <- length(ewas.Z.list) + 3
  }

  if (!is.null(ewas.png) && ncol(ewas.meta.table) > 4) {
    mfrow <- c(ncol(ewas.meta.table) - 3, ncol(ewas.meta.table) - 3)
    png(ewas.png, width = ewas.png.size, height = ewas.png.size, units = "in", res = 600)
    redf <- reduct_factor(mfrow)
    pairs(ewas.meta.table[, 2:(ncol(ewas.meta.table) - 2)],
          lower.panel = panel.cor, upper.panel = points, pch = 16,
          cex.cor = 1.1 / redf, cex.labels = 1 / redf, cex.axis = 1 / redf
    )
    dev.off()
  }

  return(ewas.meta.table)
}

#' Generate Unbiased Predictions for a New Clock based on a Training Data Set
#' @description Approximate the out-of-sample behavior of a Clock model by
#'   generating unbiased predictions using Leave-One-Out cross-validation.
#'   Generates an unbiased version of the Clock predictions using the entire
#'   training set of a corresponding Clock (an aligned metadata `ys` and an
#'   aligned and normalized methylation data `xs`).
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{List of Tables of Clock coefficients of every Leave-One-Out
#'   Clock,} \item{Table of metadata appended with unbiased Clock predictions,}
#'   \item{Plot of unbiased Clock predictions.} }
#'
#'   WARNING: This function calls [glmnet::cv.glmnet()], so the results of this
#'   function are subject to randomness. Users should add line in their R
#'   scripts calling [set.seed()] before calling this function, in order for the
#'   results to be reproducible and consistent
#'
#' @param xs Data frame, the aligned and normalized methylation data for the
#'   samples used to build a Clock (rows are samples).
#'
#'   To format `xs` correctly, use [alignDatToInfo()].
#' @param ys Data frame, the aligned metadata for the samples used to build a
#'   Clock.
#'
#'   To format `ys` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys` containing the outcome
#'   variable (typically Age, in years)
#' @param out.rdata File name/File path String (must end in ".RData"), the name
#'   and location of the file where the list of every table of coefficients for
#'   every Leave-One-Out Clock will be saved.  For more information, see Details
#'   section below
#'
#'   To skip this, use `out.rdata=NULL`.
#' @param output.csv File name/File path String (must end in ".csv"), the name
#'   and location of the file where the output data frame with unbiased
#'   predicted values will be saved.  For more information, see Details section
#'   below
#'
#'   To skip this, use `output.csv=NULL`.
#' @param out.png File name/File path String (must end in ".png"), the name and
#'   location of the file where the plot containing Leave-One-Out predictions
#'   vs. true values will be saved
#'
#'   To skip this, use `out.png=NULL`.
#' @param out.png.title String, the title to be used in the plot saved to
#'   `out.png`
#' @param PREDVAR String, the name of the NEW appended column in the output
#'   which will contain the unbiased predicted outcome variable, the output of
#'   the corresponding Leave-One-Out Clock (same units as `OUTVAR`, and
#'   typically DNAm Age)
#' @param RESVAR String, the name of the NEW appended column in the output which
#'   will contain the residual of the Leave-One-Out predictions against the true
#'   values, roughly the difference of `PREDVAR` and `OUTVAR` (same units as
#'   `OUTVAR`, and typically Age Acceleration)
#' @param ALPHA Numeric, the elasticnet mixing parameter, to be passed into
#'   [glmnet::glmnet()] and [glmnet::cv.glmnet()] (default is `0.5`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; the
#'   option to change it is mostly a formality.
#' @param NFOLD Numeric, the number of folds used for selecting `lambda`, to be
#'   passed into [glmnet::cv.glmnet()] (default is `10`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   will change computation time, at the cost of model fitting optimality.
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable, with up to two additional parameters.  For more
#'   information, see [saveBuildClock()]
#' @param fun_inv Function, the name of an R function that is the mathematical
#'   inverse of `fun_trans`, with the same parameters
#' @param fun_VAR1 String, the name of the column in `ys` containing the first
#'   parameter of `fun_trans`/`fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param fun_VAR2 String, the name of the column in `ys` containing the second
#'   parameter of `fun_trans`/`fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param COLVAR String, the name of the column in `ys` containing the coloring
#'   variable for the plot (default is `NULL`, does not color points).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param NUMVAR String, the name of the column in `ys` containing the numbering
#'   variable for the plot (default is `NULL`, does not convert points into
#'   number symbols).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param show.legend Logical, Should the plot include a legend for `COLVAR`?
#'   (default is `TRUE`)
#' @param oma.right Numeric, the size of the right outer margin for the plot, in
#'   lines of text (default is `9`).  Increase this value if the legend is being
#'   truncated (the image width will be automatically adjusted).
#' @param xs.add_train Data frame, the aligned and normalized methylation data
#'   for additional samples, which will be included in the training set at every
#'   iteration of the Leave-One-Out analysis (rows are samples).
#'
#'   To format `xs.add_train` correctly, use [alignDatToInfo()].
#' @param ys.add_train Data frame, the aligned metadata for additional samples,
#'   which will be included in the training set at every iteration of the
#'   Leave-One-Out analysis.
#'
#'   To format `ys.add_train` correctly, use [alignDatToInfo()].
#' @param loglambda.seq Numeric Vector, the sequence of `lambda` values, on the
#'   natural log scale, to be evaluated in [glmnet::cv.glmnet()], instead of the
#'   sequence automatically generated (default is `NULL`, which automatically
#'   selects 100 values, evenly spaced on the natural log scale).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   should only be modified in the case of highly heterogeneous data, when the
#'   optimal value of lambda might be lower than the range of values
#'   automatically generated.
#'
#' @details While this function only returns a single data frame, it creates and
#'   saves an additional plot, and a list of tables, directly to new files in
#'   the workspace.
#'
#'   This function performs a Leave-One-Out (LOO) analysis of a specified Clock
#'   model. For every sample (every row of `ys`), it does the following:
#'   \itemize{ \item{Creates a temporary copy of `ys` and `xs` with the selected
#'   sample removed,} \item{Fits a Clock model based on this temporary data set
#'   copy, with the same specifications as outlined in [saveBuildClock()],}
#'   \item{Saves the table of coefficients of this LOO Clock to a list of
#'   matrices,} \item{Applies this LOO Clock to the sample that was removed, and
#'   saves the predicted value (usually called DNAm Age LOO) to the output of
#'   this function.} }
#'
#'   Please note that, in order to be computationally efficient, this function
#'   does NOT perform an internal cross-validation at every iteration, to select
#'   a potentially different optimal value of the penalty parameter `lambda` for
#'   every LOO Clock.  Because all of these optimal lambda values will be very
#'   close to each other in practice, we instead choose to select ONE optimal
#'   lambda value based on the full data set, and use this value of lambda to
#'   fit every LOO Clock.
#'
#'   The output of this function is a data frame that copies `ys` and appends
#'   three additional new columns.
#'
#'   The first two appended column will be named based on the values (given by
#'   the user) of the arguments `PREDVAR` and `RESVAR`.  The final appended
#'   column is `"count_probes_selected"`, which counts how many probes were
#'   selected for in the LOO Clock corresponding to that sample.  These values
#'   are typically close to each other, and close to the number of probes
#'   selected in the corresponding final Clock trained on the full data.
#'
#'   The selected sets of probes and the coefficients for every LOO Clock are
#'   not returned, but are instead saved in the file given to the argument
#'   `out.rdata`.  This file contains a list of tables (matrices) of
#'   coefficients, and every table of coefficients within this list contains two
#'   columns.
#'
#'   For all details related to building Clocks and using coefficients files,
#'   see Details section in [saveBuildClock()].
#'
#' @return A data frame containing metadata and predicted values, created by
#'   copying `ys` and unibased appending predicted values as new columns.  The
#'   names of the new columns are specified by the arguments `PREDVAR` and
#'   `RESVAR`.
#' @export
saveLOOEstimation <- function(xs, ys, OUTVAR, out.rdata, output.csv, out.png, out.png.title, PREDVAR, RESVAR, ALPHA = 0.5, NFOLD = 10, fun_trans = fun_identity, fun_inv = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL, COLVAR = NULL, NUMVAR = NULL, show.legend = T, oma.right = 9, xs.add_train = NULL, ys.add_train = NULL, loglambda.seq = NULL) {
  rows.keep <- which(!is.na(fun_trans(ys[, OUTVAR], ys[, fun_VAR1], ys[, fun_VAR2])))
  if (length(rows.keep) < nrow(ys)) {
    print(paste(
      nrow(ys) - length(rows.keep),
      "rows in the data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    ys <- ys[rows.keep, ]
    xs <- xs[rows.keep, ]
  }

  ys.outcome <- ys[, OUTVAR]
  if (is.null(fun_VAR1)) {
    ys.funvar1 <- NULL
  } else {
    ys.funvar1 <- ys[, fun_VAR1]
  }
  if (is.null(fun_VAR2)) {
    ys.funvar2 <- NULL
  } else {
    ys.funvar2 <- ys[, fun_VAR2]
  }

  if (!is.null(xs.add_train) & !is.null(ys.add_train)) {
    rows.keep <- which(!is.na(fun_trans(ys.add_train[, OUTVAR], ys.add_train[, fun_VAR1], ys.add_train[, fun_VAR2])))
    ys.add_train <- ys.add_train[rows.keep, ]
    xs.add_train <- xs.add_train[rows.keep, ]
    ys.add_train.outcome <- ys.add_train[, OUTVAR]
    if (is.null(fun_VAR1)) {
      ys.add_train.funvar1 <- NULL
    } else {
      ys.add_train.funvar1 <- ys.add_train[, fun_VAR1]
    }
    if (is.null(fun_VAR2)) {
      ys.add_train.funvar2 <- NULL
    } else {
      ys.add_train.funvar2 <- ys.add_train[, fun_VAR2]
    }
  }

  if (is.null(loglambda.seq)) {
    lambda <- NULL
  } else {
    lambda <- exp(loglambda.seq)
  }
  glmnet.Training.CV <- cv.glmnet(xs, fun_trans(ys.outcome, ys.funvar1, ys.funvar2),
                                  nfolds = NFOLD, alpha = ALPHA, family = "gaussian", type.measure = "mse", lambda = lambda
  )
  lambda.glmnet.Training <- glmnet.Training.CV$lambda.1se
  print("Debug checkpoint 1")
  print(paste("log(Lambda) =", log(lambda.glmnet.Training)))

  ### Building LOO Clocks for each sample
  ys.prediction <- 0 * ys.outcome
  glmnet.final.list <- vector("list", length(ys.prediction))
  cpg.count <- 0 * ys.outcome
  for (i in 1:length(ys.prediction)) {
    xs.trn <- xs[-i, ]
    ys.trn.outcome <- ys.outcome[-i]
    ys.trn.funvar1 <- ys.funvar1[-i]
    ys.trn.funvar2 <- ys.funvar2[-i]
    if (!is.null(xs.add_train) & !is.null(ys.add_train)) {
      xs.trn <- rbind(xs.trn, xs.add_train)
      ys.trn.outcome <- c(ys.trn.outcome, ys.add_train.outcome)
      ys.trn.funvar1 <- c(ys.trn.funvar1, ys.add_train.funvar1)
      ys.trn.funvar2 <- c(ys.trn.funvar2, ys.add_train.funvar2)
    }
    glmnet.Training <- glmnet(xs.trn, fun_trans(ys.trn.outcome, ys.trn.funvar1, ys.trn.funvar2),
                              alpha = ALPHA, family = "gaussian", lambda = lambda.glmnet.Training
    )
    ys.prediction[i] <- fun_inv(
      as.numeric(predict(glmnet.Training, t(as.matrix(xs[i, ])), type = "response")),
      ys.funvar1[i], ys.funvar2[i]
    )
    glmnet.final <- data.frame(as.matrix(coef(glmnet.Training, s = lambda.glmnet.Training)))
    names(glmnet.final) <- "beta"
    glmnet.final$var <- rownames(glmnet.final)
    glmnet.final <- subset(glmnet.final, select = c(var, beta))
    glmnet.final.list[[i]] <- subset(glmnet.final, abs(beta) > 0)
    cpg.count[i] <- nrow(subset(glmnet.final, abs(beta) > 0))
  }
  if (!is.null(out.rdata)) {
    save(glmnet.final.list, file = out.rdata)
  }
  print("Debug checkpoint 2")
  ys.output <- ys
  ys.output[, PREDVAR] <- ys.prediction
  attr(ys.output[, PREDVAR], "dimnames") <- NULL
  ys.output[, RESVAR] <- residuals(lm(ys.prediction ~ ys.outcome))
  attr(ys.output[, RESVAR], "dimnames") <- NULL
  ys.output[, "count_probes_selected"] <- cpg.count
  print("Debug checkpoint 3")

  if (!is.null(output.csv)) {
    write.table(ys.output, output.csv, sep = ",", row.names = F, quote = F)
  }
  if (!is.null(out.png)) {
    TITLE_str <- paste0(out.png.title, "\n")
    saveValidationPlot(ys.output, OUTVAR, PREDVAR, COLVAR, out.png, TITLE_str, show.legend = show.legend, oma.right = oma.right, NUMVAR = NUMVAR)
  }

  return(ys.output)
}

#' Generate Unbiased Predictions for a Set of New Clocks based on a Training
#' Data Set, Stratified by Species
#' @description Approximate the out-of-sample behavior of a set of independent
#'   Clock models by generating unbiased predictions using stratified
#'   Leave-One-Out cross-validation. Generates an unbiased version of the Clock
#'   predictions within each stratum, using the entire training set of a
#'   corresponding Clock (an aligned metadata `ys` and an aligned and normalized
#'   methylation data `xs`).
#'
#'   This function should be used if you have a significant number of samples
#'   from multiple different species, and would like to a set of build
#'   single-species Clocks simultaneously.
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Multiple Lists of Tables (one for each stratum) of Clock
#'   coefficients of every Leave-One-Out Clock,} \item{Table of metadata
#'   appended with all unbiased Clock predictions,} \item{Plot of all unbiased
#'   Clock predictions.} }
#'
#'   WARNING: This function calls [glmnet::cv.glmnet()], so the results of this
#'   function are subject to randomness. Users should add line in their R
#'   scripts calling [set.seed()] before calling this function, in order for the
#'   results to be reproducible and consistent
#'
#' @param xs Data frame, the aligned and normalized methylation data for the
#'   samples used to build a set of independent Clocks (rows are samples).
#'
#'   To format `xs` correctly, use [alignDatToInfo()].
#' @param ys Data frame, the aligned metadata for the samples used to build a
#'   set of independent Clocks.
#'
#'   To format `ys` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys` containing the outcome
#'   variable (typically Age, in years)
#' @param STRATVAR String, the name of the column in `ys` containing the
#'   stratifying variable (typically Species Name), by which to stratify `ys`
#'   and perform separate Leave-One-Out analyses.
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param out.rdata.PREFIX File name/File path String PREFIX (meaning a file
#'   name or file path without the '.RData' at the end), the name and location
#'   of the files where the lists (one list for each stratum) of every table of
#'   coefficients for every Leave-One-Out Clock will be saved.
#'
#'   To skip this, use `out.rdata.PREFIX=NULL`.
#' @param output.csv File name/File path String (must end in ".csv"), the name
#'   and location of the file where the output data frame with unbiased
#'   predicted values will be saved.  For more information, see Details section
#'   below
#'
#'   To skip this, use `output.csv=NULL`.
#' @param out.png File name/File path String (must end in ".png"), the name and
#'   location of the file where the plot containing Leave-One-Out predictions
#'   vs. true values will be saved
#'
#'   To skip this, use `out.png=NULL`.
#' @param out.png.title String, the title to be used in the plot saved to
#'   `out.png`
#' @param PREDVAR String, the name of the NEW appended column in the output
#'   which will contain the unbiased predicted outcome variable, the output of
#'   the corresponding stratifed Leave-One-Out Clock (same units as `OUTVAR`,
#'   and typically DNAm Age)
#' @param RESVAR String, the name of the NEW appended column in the output which
#'   will contain the residual of the Leave-One-Out predictions against the true
#'   values, roughly the difference of `PREDVAR` and `OUTVAR` (same units as
#'   `OUTVAR`, and typically Age Acceleration)
#' @param ALPHA Numeric, the elasticnet mixing parameter, to be passed into
#'   [glmnet::glmnet()] and [glmnet::cv.glmnet()] (default is `0.5`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; the
#'   option to change it is mostly a formality.
#' @param NFOLD Numeric, the number of folds used for selecting `lambda`, to be
#'   passed into [glmnet::cv.glmnet()] (default is `10`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   will change computation time, at the cost of model fitting optimality.
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable, with up to two additional parameters.  For more
#'   information, see [saveBuildClock()]
#' @param fun_inv Function, the name of an R function that is the mathematical
#'   inverse of `fun_trans`, with the same parameters
#' @param fun_VAR1 String, the name of the column in `ys` containing the first
#'   parameter of `fun_trans`/`fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param fun_VAR2 String, the name of the column in `ys` containing the second
#'   parameter of `fun_trans`/`fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param COLVAR String, the name of the column in `ys` containing the coloring
#'   variable for the plot (default is `NULL`, does not color points).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param NUMVAR String, the name of the column in `ys` containing the numbering
#'   variable for the plot (default is `NULL`, does not convert points into
#'   number symbols).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param show.legend Logical, Should the plot include a legend for `COLVAR`?
#'   (default is `TRUE`)
#' @param oma.right Numeric, the size of the right outer margin for the plot, in
#'   lines of text (default is `9`).  Increase this value if the legend is being
#'   truncated (the image width will be automatically adjusted).
#' @param xs.add_train Data frame, the aligned and normalized methylation data
#'   for additional samples, which will be included (after also being
#'   stratified) in the training set at every iteration of the appropriate
#'   Leave-One-Out analysis (rows are samples).
#'
#'   To format `xs.add_train` correctly, use [alignDatToInfo()].
#' @param ys.add_train Data frame, the aligned metadata for additional samples,
#'   which will be included (after also being stratified) in the training set at
#'   every iteration of the appropriate Leave-One-Out analysis.
#'
#'   To format `ys.add_train` correctly, use [alignDatToInfo()].
#'
#' @details While this function only returns a single data frame, it creates and
#'   saves an additional plot, and multiple lists of tables, directly to new
#'   files in the workspace.
#'
#'   This function performs a set of simultaneous and independent Leave-One-Out
#'   (LOO) analyses of a specified Clock model on a stratified data set. In
#'   other words, for every stratum, it performs a LOO analysis using the same
#'   Clock model.  For all details related to LOO Analysis, see Details section
#'   of [saveLOOEstimation()].
#'
#'   The output of this function is a data frame that copies `ys` and appends
#'   three additional new columns.
#'
#'   The first two appended column will be named based on the values (given by
#'   the user) of the arguments `PREDVAR` and `RESVAR`.  The final appended
#'   column is `"count_probes_selected"`, which counts how many probes were
#'   selected for in the LOO Clock corresponding to that sample and that strata.
#'   These values are typically close to each other, and close to the number of
#'   probes selected in the corresponding final stratified Clock trained on the
#'   full data.
#'
#'   The selected sets of probes and the coefficients for every LOO Clock are
#'   not returned, but are instead saved in multiple files, named based on the
#'   file prefix given to the argument `out.rdata.PREFIX`.  There is one RData
#'   file corresponding to each strata within the data.  Each of these files
#'   contains a single list of tables (matrices) of coefficients, and every
#'   table of coefficients within this list contains two columns.
#'
#'   For all details related to building Clocks and using coefficients files,
#'   see Details section in [saveBuildClock()].
#'
#' @return A data frame containing metadata and predicted values, created by
#'   copying `ys` and unibased appending predicted values as new columns.  The
#'   names of the new columns are specified by the arguments `PREDVAR` and
#'   `RESVAR`.
#' @export
saveLOOEstimationStrat <- function(xs, ys, OUTVAR, STRATVAR, out.rdata.PREFIX, output.csv, out.png, out.png.title, PREDVAR, RESVAR, ALPHA = 0.5, NFOLD = 10, fun_trans = fun_identity, fun_inv = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL, COLVAR = NULL, NUMVAR = NULL, show.legend = T, oma.right = 9, xs.add_train = NULL, ys.add_train = NULL) {
  if (is.null(STRATVAR)) {
    stop("STRATVAR cannot be NULL")
  }
  if (!is.factor(ys[, STRATVAR])) {
    stop("STRATVAR must correspond to a factor-type column")
  }

  ys.add_train[, STRATVAR] <- factor(ys.add_train[, STRATVAR], levels = ys[, STRATVAR])

  rows.keep <- which(!is.na(fun_trans(ys[, OUTVAR], ys[, fun_VAR1], ys[, fun_VAR2])))
  if (length(rows.keep) < nrow(ys)) {
    print(paste(
      nrow(ys) - length(rows.keep),
      "rows in the data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    print("WARNING: Because of this, levels of STRATVAR may have been removed and reordered")
    ys <- ys[rows.keep, ]
    xs <- xs[rows.keep, ]
    ys[, STRATVAR] <- factor(ys[, STRATVAR])
    ys.add_train[, STRATVAR] <- factor(ys.add_train[, STRATVAR], levels = ys[, STRATVAR])
  }

  ys.outcome <- ys[, OUTVAR]

  if (!is.null(xs.add_train) & !is.null(ys.add_train)) {
    rows.keep.add <- which(!is.na(fun_trans(ys.add_train[, OUTVAR], ys.add_train[, fun_VAR1], ys.add_train[, fun_VAR2])))
    if (length(rows.keep.add) < nrow(ys.add_train)) {
      print(paste(
        nrow(ys.add_train) - length(rows.keep.add),
        "rows in the additional data were ignored, because `fun_trans` outputs NA for those samples"
      ))
      ys.add_train <- ys.add_train[rows.keep.add, ]
      xs.add_train <- xs.add_train[rows.keep.add, ]
    }
  }
  print("Debug checkpoint 1")

  ### Building a set of LOO Clocks, one for each level of STRATVAR
  ys.output <- data.frame()
  for (strat.num in 1:length(levels(ys[, STRATVAR]))) {
    print(paste0(round((strat.num - 1) / length(levels(ys[, STRATVAR])) * 100), "%"))
    strat.name <- levels(ys[, STRATVAR])[strat.num]
    indcs <- which(as.numeric(ys[, STRATVAR]) == strat.num)
    indcs.add <- which(as.numeric(ys.add_train[, STRATVAR]) == strat.num)
    print(paste("Debug checkpoint: Stratum", strat.name))
    if (length(unique(ys.outcome[indcs])) <= 2 && min(table(ys.outcome[indcs])) == 1) {
      stop(paste0(
        "Stratum \"", strat.name,
        "\" could not be modelled (not enough samples/unique values of the outcome)"
      ))
    }
    if (!is.null(out.rdata.PREFIX)) {
      out.rdata <- paste0(out.rdata.PREFIX, snakecase::to_upper_camel_case(strat.name), ".RData")
    } else {
      out.rdata <- NULL
    }
    ys.output.num <- saveLOOEstimation(xs[indcs, ], ys[indcs, ], OUTVAR, out.rdata, output.csv = NULL, out.png = NULL, out.png.title = NULL, PREDVAR, RESVAR, ALPHA, NFOLD, fun_trans = fun_trans, fun_inv = fun_inv, fun_VAR1 = fun_VAR1, fun_VAR2 = fun_VAR2, xs.add_train = xs.add_train[indcs.add, ], ys.add_train = ys.add_train[indcs.add, ])
    ys.output <- rbind(ys.output, ys.output.num)
  }
  print("100%")

  if (!is.null(output.csv)) {
    write.table(ys.output, output.csv, sep = ",", row.names = F, quote = F)
  }
  if (!is.null(out.png)) {
    TITLE_str <- paste0(out.png.title, "\n")
    saveValidationPlot(ys.output, OUTVAR, PREDVAR, COLVAR, out.png, TITLE_str, show.legend = show.legend, oma.right = oma.right, NUMVAR = NUMVAR)
  }

  return(ys.output)
}

#' Generate Species-Level Unbiased Predictions for a New Multi-Species Clock
#' based on a Training Data Set
#' @description Approximate the out-of-sample behavior of a multi-species Clock
#'   model on new species by generating unbiased predictions using
#'   Leave-One-Species-Out cross-validation. Generates an unbiased version of
#'   the Clock predictions using the entire training set of a corresponding
#'   Clock (an aligned metadata `ys` and an aligned and normalized methylation
#'   data `xs`).
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{List of Tables of Clock coefficients of every
#'   Leave-One-Species-Out Clock,} \item{Table of metadata appended with
#'   unbiased Clock predictions,} \item{Plot of unbiased Clock predictions.} }
#'
#'   WARNING: This function calls [glmnet::cv.glmnet()], so the results of this
#'   function are subject to randomness. Users should add line in their R
#'   scripts calling [set.seed()] before calling this function, in order for the
#'   results to be reproducible and consistent
#'
#' @param xs Data frame, the aligned and normalized methylation data for the
#'   samples used to build a Clock (rows are samples).
#'
#'   To format `xs` correctly, use [alignDatToInfo()].
#' @param ys Data frame, the aligned metadata for the samples used to build a
#'   Clock.
#'
#'   To format `ys` correctly, use [alignDatToInfo()].
#' @param OUTVAR String, the name of the column in `ys` containing the outcome
#'   variable (typically Age, in years)
#' @param SPECVAR String, the name of the column in `ys` containing the
#'   stratifying variable (typically Species Name).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param out.rdata File name/File path String (must end in ".RData"), the name
#'   and location of the file where the list of every table of coefficients for
#'   every Leave-One-Species-Out Clock will be saved.  For more information, see
#'   Details section below
#'
#'   To skip this, use `out.rdata=NULL`.
#' @param output.csv File name/File path String (must end in ".csv"), the name
#'   and location of the file where the output data frame with unbiased
#'   predicted values will be saved.  For more information, see Details section
#'   below
#'
#'   To skip this, use `output.csv=NULL`.
#' @param out.png File name/File path String (must end in ".png"), the name and
#'   location of the file where the plot containing Leave-One-Species-Out
#'   predictions vs. true values will be saved
#'
#'   To skip this, use `out.png=NULL`.
#' @param out.png.title String, the title to be used in the plot saved to
#'   `out.png`
#' @param PREDVAR String, the name of the NEW appended column in the output
#'   which will contain the unbiased predicted outcome variable, the output of
#'   the corresponding Leave-One-Species-Out Clock (same units as `OUTVAR`, and
#'   typically DNAm Age)
#' @param RESVAR String, the name of the NEW appended column in the output which
#'   will contain the residual of the Leave-One-Species-Out predictions against
#'   the true values, roughly the difference of `PREDVAR` and `OUTVAR` (same
#'   units as `OUTVAR`, and typically Age Acceleration)
#' @param ALPHA Numeric, the elasticnet mixing parameter, to be passed into
#'   [glmnet::glmnet()] and [glmnet::cv.glmnet()] (default is `0.5`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; the
#'   option to change it is mostly a formality.
#' @param NFOLD Numeric, the number of folds used for selecting `lambda`, to be
#'   passed into [glmnet::cv.glmnet()] (default is `10`).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   will change computation time, at the cost of model fitting optimality.
#' @param fun_trans Function, the name of an R function that transforms the
#'   outcome variable, with up to two additional parameters.  For more
#'   information, see [saveBuildClock()]
#' @param fun_inv Function, the name of an R function that is the mathematical
#'   inverse of `fun_trans`, with the same parameters
#' @param fun_VAR1 String, the name of the column in `ys` containing the first
#'   parameter of `fun_trans`/`fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param fun_VAR2 String, the name of the column in `ys` containing the second
#'   parameter of `fun_trans`/`fun_inv`, if any (default is `NULL`, meaning no
#'   parameter is required)
#' @param COLVAR String, the name of the column in `ys` containing the coloring
#'   variable for the plot (default is `NULL`, does not color points).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param NUMVAR String, the name of the column in `ys` containing the numbering
#'   variable for the plot (default is `NULL`, does not convert points into
#'   number symbols).
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param show.legend Logical, Should the plot include a legend for `COLVAR`?
#'   (default is `TRUE`)
#' @param oma.right Numeric, the size of the right outer margin for the plot, in
#'   lines of text (default is `9`).  Increase this value if the legend is being
#'   truncated (the image width will be automatically adjusted).
#' @param cpg_names.list List of String Vectors, the probe names used for
#'   pre-filtering for each iteration of the Leave-One-Species-Out analysis. The
#'   elements of `cpg_names.list` should match with the `levels(ys[,SPECVAR])`
#'   in order
#' @param xs.add_train Data frame, the aligned and normalized methylation data
#'   for additional samples, which will be included in the training set at every
#'   iteration of the Leave-One-Species-Out analysis, regardless of species
# `   (rows are samples).
#'
#'   To format `xs.add_train` correctly, use [alignDatToInfo()].
#' @param ys.add_train Data frame, the aligned metadata for additional samples,
#'   which will be included in the training set at every iteration of the
#'   Leave-One-Species-Out analysis, regardless of species.
#'
#'   To format `ys.add_train` correctly, use [alignDatToInfo()].
#' @param loglambda.seq Numeric Vector, the sequence of `lambda` values, on the
#'   natural log scale, to be evaluated in [glmnet::cv.glmnet()] every time,
#'   instead of the sequences automatically generated (default is `NULL`, which
#'   automatically selects 100 values, evenly spaced on the natural log scale).
#'
#'   WARNING: Do not change this argument unless you understand what it is; it
#'   should only be modified in the case of highly heterogeneous data, when the
#'   optimal value of lambda might be lower than the range of values
#'   automatically generated.
#'
#' @details While this function only returns a single data frame, it creates and
#'   saves an additional plot, and a list of tables, directly to new files in
#'   the workspace.
#'
#'   This function performs a Leave-One-Species-Out (LOSO) analysis of a
#'   specified Clock model. For every species (level) in `ys`, it does the
#'   following:
#'   \itemize{ \item{Creates a temporary copy of `ys` and `xs` with all
#'   samples from the selected species removed,} \item{Fits a Clock model based
#'   on this temporary data set copy, with the same specifications as outlined
#'   in [saveBuildClock()],} \item{Saves the table of coefficients of this LOSO
#'   Clock to a list of matrices,} \item{Applies this LOSO Clock to all of the
#'   samples that were removed, and saves the predicted values (usually called
#'   DNAm Age LOSO) to the output of this function.} }
#'
#'   Please note that, unlike in [saveLOOEstimation()], a new optimal lambda is
#'   selected (via internal cross-validation) during every iteration of LOSO.
#'   This is done because all of these optimal lambda values will likely be
#'   significantly different to each other in practice.
#'
#'   The output of this function is a data frame that copies `ys` and appends
#'   four additional new columns.
#'
#'   The first two appended column will be named based on the values (given by
#'   the user) of the arguments `PREDVAR` and `RESVAR`.  The third appended
#'   column is `"count_probes_selected"`, which counts how many probes were
#'   selected for in the LOSO Clock corresponding to that sample's species.
#'   These values may be quite different, depending on how different the species
#'   in the data are.
#'
#'   The final appended column is `"log_lambda_hat"`, which is the natural log
#'   of the optimal lambda that is selected based on [glmnet::cv.glmnet()].  If
#'   you manually specify `loglambda.seq` and observe that many of these values
#'   are at one end of the sequence range, it is recommended that you re-specify
#'   `loglambda.seq`.
#'
#'   The selected sets of probes and the coefficients for every LOSO Clock are
#'   not returned, but are instead saved in the file given to the argument
#'   `out.rdata`.  This file contains a list of tables (matrices) of
#'   coefficients, and every table of coefficients within this list contains two
#'   columns.
#'
#'   For all details related to building Clocks and using coefficients files,
#'   see Details section in [saveBuildClock()].
#'
#' @return A data frame containing metadata and predicted values, created by
#'   copying `ys` and unibased appending predicted values as new columns.  The
#'   names of the new columns are specified by the arguments `PREDVAR` and
#'   `RESVAR`.
#' @export
saveLOSOEstimation <- function(xs, ys, OUTVAR, SPECVAR, out.rdata, output.csv, out.png, out.png.title, PREDVAR, RESVAR, ALPHA = 0.5, NFOLD = 10, fun_trans = fun_identity, fun_inv = fun_identity, fun_VAR1 = NULL, fun_VAR2 = NULL, COLVAR = NULL, NUMVAR = NULL, show.legend = T, oma.right = 9, cpg_names.list = NULL, xs.add_train = NULL, ys.add_train = NULL, loglambda.seq = NULL) {
  if (is.null(SPECVAR)) {
    stop("SPECVAR cannot be NULL")
  }
  if (!is.factor(ys[, SPECVAR])) {
    stop("SPECVAR must correspond to a factor-type column")
  }

  rows.keep <- which(!is.na(fun_trans(ys[, OUTVAR], ys[, fun_VAR1], ys[, fun_VAR2])))
  if (length(rows.keep) < nrow(ys)) {
    print(paste(
      nrow(ys) - length(rows.keep),
      "rows in the data were ignored, because `fun_trans` outputs NA for those samples"
    ))
    print("WARNING: Because of this, levels of SPECVAR may have been removed and reordered")
    ys <- ys[rows.keep, ]
    xs <- xs[rows.keep, ]
    ys[, SPECVAR] <- factor(ys[, SPECVAR])
    xs[, SPECVAR] <- factor(xs[, SPECVAR])
  }

  ys.outcome <- ys[, OUTVAR]
  if (is.null(fun_VAR1)) {
    ys.funvar1 <- NULL
  } else {
    ys.funvar1 <- ys[, fun_VAR1]
  }
  if (is.null(fun_VAR2)) {
    ys.funvar2 <- NULL
  } else {
    ys.funvar2 <- ys[, fun_VAR2]
  }
  ys.species <- ys[, SPECVAR]
  if (!is.null(cpg_names.list) & length(cpg_names.list) != length(levels(ys.species))) {
    stop("Please check that the length of cpg_names.list matches the number of groups in ys[,SPECVAR]")
  }

  if (!is.null(xs.add_train) & !is.null(ys.add_train)) {
    rows.keep <- which(!is.na(fun_trans(ys.add_train[, OUTVAR], ys.add_train[, fun_VAR1], ys.add_train[, fun_VAR2])))
    ys.add_train <- ys.add_train[rows.keep, ]
    xs.add_train <- xs.add_train[rows.keep, ]
    ys.add_train.outcome <- ys.add_train[, OUTVAR]
    if (is.null(fun_VAR1)) {
      ys.add_train.funvar1 <- NULL
    } else {
      ys.add_train.funvar1 <- ys.add_train[, fun_VAR1]
    }
    if (is.null(fun_VAR2)) {
      ys.add_train.funvar2 <- NULL
    } else {
      ys.add_train.funvar2 <- ys.add_train[, fun_VAR2]
    }
  }
  print("Debug checkpoint 1")

  ### Building LOSO Clocks for each level of SPECVAR
  ys.prediction <- 0 * ys.outcome
  glmnet.final.list <- vector("list", length(ys.prediction))
  cpg.count <- 0 * ys.outcome
  log_lambda.hat <- 0 * ys.outcome
  if (is.null(loglambda.seq)) {
    lambda <- NULL
  } else {
    lambda <- exp(loglambda.seq)
  }
  for (spec.num in 1:length(levels(ys.species))) {
    print(paste0(round((spec.num - 1) / length(levels(ys.species)) * 100), "%"))
    indcs <- which(as.numeric(ys.species) == spec.num)
    if (!is.null(cpg_names.list)) {
      cpg_names.num <- cpg_names.list[[spec.num]]
    } else {
      cpg_names.num <- colnames(xs)
    }
    if (length(indcs) > 0) {
      xs.trn <- xs[-indcs, ]
      ys.trn.outcome <- ys.outcome[-indcs]
      ys.trn.funvar1 <- ys.funvar1[-indcs]
      ys.trn.funvar2 <- ys.funvar2[-indcs]
      if (!is.null(xs.add_train) & !is.null(ys.add_train)) {
        xs.trn <- rbind(xs.trn, xs.add_train)
        ys.trn.outcome <- c(ys.trn.outcome, ys.add_train.outcome)
        ys.trn.funvar1 <- c(ys.trn.funvar1, ys.add_train.funvar1)
        ys.trn.funvar2 <- c(ys.trn.funvar2, ys.add_train.funvar2)
      }
      glmnet.Training.CV <- cv.glmnet(xs.trn[, cpg_names.num], fun_trans(ys.trn.outcome, ys.trn.funvar1, ys.trn.funvar2),
                                      nfolds = NFOLD, alpha = ALPHA, family = "gaussian", type.measure = "mse", lambda = lambda
      )
      print("Debug checkpoint 1.1")
      lambda.glmnet.Training <- glmnet.Training.CV$lambda.1se
      glmnet.Training <- glmnet(xs.trn[, cpg_names.num], fun_trans(ys.trn.outcome, ys.trn.funvar1, ys.trn.funvar2),
                                alpha = ALPHA, family = "gaussian", lambda = lambda.glmnet.Training
      )
      print("Debug checkpoint 1.2")
      xs.other <- xs[indcs, cpg_names.num]
      if (length(indcs) == 1) {
        xs.other <- t(as.matrix(xs[indcs, cpg_names.num]))
      }
      ys.prediction[indcs] <- fun_inv(
        as.numeric(predict(glmnet.Training, xs.other, type = "response")),
        ys.funvar1[indcs], ys.funvar2[indcs]
      )
      glmnet.final <- data.frame(as.matrix(coef(glmnet.Training, s = lambda.glmnet.Training)))
      names(glmnet.final) <- "beta"
      glmnet.final$var <- rownames(glmnet.final)
      glmnet.final <- subset(glmnet.final, select = c(var, beta))
      for (i in indcs) {
        glmnet.final.list[[i]] <- subset(glmnet.final, abs(beta) > 0)
      }
      cpg.count[indcs] <- nrow(subset(glmnet.final, abs(beta) > 0))
      log_lambda.hat[indcs] <- log(lambda.glmnet.Training)
    }
  }
  print("100%")
  if (!is.null(out.rdata)) {
    save(glmnet.final.list, file = out.rdata)
  }
  print("Debug checkpoint 2")
  ys.output <- ys
  ys.output[, PREDVAR] <- ys.prediction
  attr(ys.output[, PREDVAR], "dimnames") <- NULL
  ys.output[, RESVAR] <- residuals(lm(ys.prediction ~ ys.outcome))
  attr(ys.output[, RESVAR], "dimnames") <- NULL
  ys.output[, "count_probes_selected"] <- cpg.count
  ys.output[, "log_lambda_hat"] <- log_lambda.hat
  print("Debug checkpoint 3")

  if (!is.null(output.csv)) {
    write.table(ys.output, output.csv, sep = ",", row.names = F, quote = F)
  }
  if (!is.null(out.png)) {
    TITLE_str <- paste0(out.png.title, "\n")
    saveValidationPlot(ys.output, OUTVAR, PREDVAR, COLVAR, out.png, TITLE_str, show.legend = show.legend, oma.right = oma.right, NUMVAR = NUMVAR)
  }

  return(ys.output)
}

#' Estimate Hazard Ratios for Age Acceleration and Other Factors
#' @description Estimate the level of association between Age Acceleration (or
#'   other covariates) on survival time, after building a new Clock or applying
#'   an built Clock.  Estimates coefficients using GEE and fits a survival curve
#'   to the data using the metadata of the entire training set of a
#'   corresponding Clock (an aligned metadata `ys`).
#'
#'   Files generated and saved by this function:
#'   \itemize{ \item{Table of GEE coefficients,} \item{Image of table of GEE
#'   coefficients,} \item{Plot of fitted survival curve.} \item{Plot of fitted
#'   survival curve combined with table of GEE coefficients.} }
#'
#' @param ys.output Data frame, the aligned metadata for the samples, after a
#'   Clock been applied and predictions (typically DNAm Age) and residuals
#'   (typically Age Acceleration) have been generated.
#' @param TIMEVAR String, the name of the column in `ys.output` containing the
#'   survival time variable (the amount of time that the individual survived
#'   after the study began)
#' @param STATUSVAR String, the name of the column in `ys.output` containing the
#'   survival status indicator variable (`TRUE` indicates death)
#'
#'   NOTE: This variable must be encoded as a [base::logical()].
#' @param COVARS String or String Vector, the name(s) of the column(s) in
#'   `ys.output` containing the covariate variable(s) of interest for the
#'   survival analysis, such as Age Acceleration from a built Clock, or a
#'   treatment/control variable.
#'
#'   To include no covariates (and use the intercept-only model), use
#'   `COVARS=NULL`.
#' @param coxphtable.tsv File name/File path String (must end in ".tsv"), the
#'   name and location of the file where the GEE summary table will be saved.
#'   For more information, see [tab::tabcoxph()]
#' @param coxphtable.png File name/File path String (must end in ".png"), the
#'   name and location of the file where an image of the GEE summary table
#'   (useful for presenting) will be saved
#'
#'   To skip this, use `coxphtable.png=NULL`.
#' @param coxph.png File name/File path String (must end in ".png"), the name
#'   and location of the file where the fitted survival curve plot will be saved
#'
#'   To skip this, use `coxph.png=NULL`.
#' @param coxphcombined.png File name/File path String (must end in ".png"), the
#'   name and location of the file where the fitted survival curve plot,
#'   combined with an image of the GEE summary table, will be saved
#'
#'   To skip this, use `coxphcombined.png=NULL`.
#' @param coxph.png.title String, the title to be used in all three of the plots
#'   saved
#' @param STRATVAR String or String Vector, the name(s) of the column(s) in
#'   `ys.output` containing the stratifying variable(s) (default is `NULL`, does
#'   not stratify the survival model)
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#' @param CLUSTVAR String, the name of the column in `ys.output` containing the
#'   clustering variable (default is `NULL`, does not cluster the data)
#'
#'   NOTE: This variable must be encoded as a [base::factor()].
#'
#' @details While this function returns nothing, it creates and saves a table
#'   and three plots directly to new files in the workspace.
#'
#'   This function performs a survival analysis of a specified covariate (or
#'   covariates) on survival time. This function is included in this package
#'   with the intended use of performing a survival analysis on the residual
#'   variable (typically Age Acceleration) generated by [saveBuildClock()] or
#'   [saveApplyClock()].
#'
#'   This function provides the option to stratify the survival analysis by one
#'   or more variables, or to cluster the samples according to a given variable.
#'   For more information, see [survival::coxph()].
#'
#'   Please note that this function will always include the intercept term in
#'   the model.
#'
#'   For all details related to performing a survival analysis and fitting the
#'   regression model, see Details section in [survival::coxph()].
#'
#' @return Nothing.
#' @export
saveSurvivalAnalysis <- function(ys.output, TIMEVAR, STATUSVAR, COVARS, coxphtable.tsv, coxphtable.png, coxph.png, coxphcombined.png, coxph.png.title, STRATVAR = NULL, CLUSTVAR = NULL) {
  requireNamespace("survival")
  requireNamespace("tab")
  requireNamespace("grid")
  requireNamespace("gridExtra")
  requireNamespace("gtable")

  if (!is.logical(ys.output[, STATUSVAR])) {
    stop("STATUSVAR must correspond to a logical-type column")
  }

  ### Building regression model formula
  fm.str <- paste0("Surv(", TIMEVAR, ",", STATUSVAR, ")~", paste(c("1", COVARS), collapse = "+"))
  if (!is.null(STRATVAR)) {
    if (!is.factor(ys.output[, STRATVAR])) {
      stop("STRATVAR must correspond to a factor-type column")
    }
    fm.str <- paste0(fm.str, "+strata(", paste(STRATVAR, collapse = ","), ")")
  }
  fm <- as.formula(fm.str)

  ### Fitting Cox PH regression model
  if (!is.null(CLUSTVAR)) {
    if (!is.factor(ys.output[, CLUSTVAR])) {
      stop("CLUSTVAR must correspond to a factor-type column")
    }
    coxph.object <- survival::coxph(fm, data = ys.output, na.action = na.exclude, cluster = as.formula(CLUSTVAR))
  } else {
    coxph.object <- survival::coxph(fm, data = ys.output, na.action = na.exclude)
  }

  ### Summarizing Cox PH regression model
  coxph.table <- tab::tabcoxph(coxph.object, factor.compression = 2, decimals = 3)
  # coxph.png.subtitle = paste0("Concordance = ",round(coxph.object$concordance["concordance"],3),
  #                            " (",round(coxph.object$concordance["std"],3),")")
  coxph.plot <- autoplot(survival::survfit(coxph.object),
                         xlab = TIMEVAR, ylab = "Survival", main = coxph.png.title
  ) +
    theme_bw(base_size = 13) + theme(plot.title = element_text(size = 10, hjust = 0.5))

  ### Saving table
  write.table(coxph.table, coxphtable.tsv, sep = "\t", row.names = F, quote = F)

  ### Saving images
  coxph.tg <- gridExtra::tableGrob(coxph.table,
                                   rows = NULL,
                                   theme = gridExtra::ttheme_default(base_size = 13, padding = unit(c(0.25, 0.15), "in"))
  )
  coxph.tg.title <- grid::textGrob(coxph.png.title, gp = grid::gpar(fontsize = 7))
  coxph.tg2 <- gtable::gtable_add_rows(coxph.tg, heights = grid::grobHeight(coxph.tg.title) + unit(0.15, "in"), pos = 0)
  coxph.tg2 <- gtable::gtable_add_grob(coxph.tg2, coxph.tg.title, 1, 1, 1, ncol(coxph.tg))
  ## grDevices::dev.size() is the default size in ggsave() when length(grDevices::dev.list()) != 0
  ## c(7,7) is the default size in ggsave() when length(grDevices::dev.list()) == 0
  if (!is.null(coxphtable.png)) {
    ggsave(coxphtable.png,
           grid::grid.draw(coxph.tg2),
           width = sum(grid::convertX(coxph.tg2$widths, "in", valueOnly = T)) + 0.15,
           height = sum(grid::convertX(coxph.tg2$heights, "in", valueOnly = T)) + 0.15
    )
    dev.off() # Always call dev.off() after calling grid::convertX()
  }
  if (!is.null(coxph.png)) {
    ggsave(coxph.png,
           coxph.plot,
           width = 5, height = 6
    )
  }
  if (!is.null(coxphcombined.png)) {
    ggsave(coxphcombined.png,
           gridExtra::grid.arrange(coxph.plot, coxph.tg, heights = grid::unit.c(unit(1, "null"), sum(coxph.tg$heights, unit(0.15, "in")))),
           width = 5, height = 6
    )
  }
}
