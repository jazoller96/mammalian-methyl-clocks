## Defining internal helper functions
## Author: Joseph Zoller

# matches_any <- Vectorize(function(x, str.vec) {
#   matchl_vec <- str.vec %in% x
#   return(any(matchl_vec))
# }, vectorize.args="x", USE.NAMES=F)
# startsWith_any <- Vectorize(function(x, str.vec) {
#   grepl_vec <- sapply(str.vec, function(prefix, str) {startsWith(str, prefix)}, x)
#   return(any(grepl_vec))
# }, vectorize.args="x", USE.NAMES=F)
# contains_any <- Vectorize(function(x, str.vec) {
#   grepl_vec <- sapply(str.vec, grepl, x)
#   return(any(grepl_vec))
# }, vectorize.args="x", USE.NAMES=F)

# folder_full_names <- Vectorize(function(x, folders.vec) {
#   return(grep(x, folders.vec, value=T))
# }, vectorize.args="x", USE.NAMES=F)


