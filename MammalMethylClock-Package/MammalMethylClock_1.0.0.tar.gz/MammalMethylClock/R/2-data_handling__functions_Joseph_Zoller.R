## Defining helper functions for data importing, data wrangling, and re-factoring
## Author: Joseph Zoller

#' Load RData File as an Object
#' @description Load an RData file containing one object, and capture said
#'   object rather than automatically adding it to the workspace.
#'
#' @param data.rdata String, the name of the file to load (ending in .rdata)
#'
#' @details RData files contain the contents of a workspace when they are
#'   created, so loading them does not directly capture objects.  When an RData
#'   file contains only one object (like a dataframe), it is more convenient to
#'   have a function that loads the RData file and captures the single object.
#'
#' @return An object, being the single object saved within the RData file.
#' @export
loadRData <- function(data.rdata) {
  load(data.rdata)
  get(ls()[ls() != "data.rdata"])
}

#' Data Frame Transpose when Column Names and First Column contain labels
#' @description Given a data frame where the first column contains labels for
#'   the rows, return the modified transpose.
#'
#' @param dat_tp Data frame to be transposed
#' @param VAR.label String, the name of the first column of the modified
#'   transpose, that will contain the colnames(dat_tp)
#'
#' @details This is a speciality function for handling unique data frame
#'   formatting patterns, where the row labels are in the first column rather
#'   than the row names.
#'
#'   The first column is pushed into the row names, then the data frame is
#'   transposed.  Finally, the new row names are pulled out into the new first
#'   column.  The new first column will be of type character.
#'
#' @return A data frame, the modified transpose of dat_tp.
#' @export
transpose_dat <- function(dat_tp, VAR.label) {
  #VAR.label=String, name of the new first column containing original colnames
  dat <- column_to_rownames(dat_tp, colnames(dat_tp)[1]) %>% as.data.frame()
  dat <- dat <- dat %>% t() %>% as.data.frame()
  dat <- rownames_to_column(dat, VAR.label) %>% as.data.frame()
  return(dat)
}

#' Minimally Combine Data Frames by Rows
#' @description Merge two data frames with [base::rbind()], only keeping column
#'   names present in both data frames.
#'
#' @param x,y Data frames
#'
#' @details Before calling [base::rbind()], it filters the columns of x and y to
#'   those that they both share
#'
#' @return A data frame, the result of merging x and y by rows.
#' @export
rbind2.inner <- function(x, y) {
  xy.intersect <- intersect(colnames(x), colnames(y))
  x <- x[, as.character(xy.intersect)]
  y <- y[, as.character(xy.intersect)]
  return(rbind(x,y))
}
#' Maximally Combine Data Frames by Rows
#' @description Merge two data frames with [base::rbind()], keeping all column
#'   names present in either data frame.
#'
#' @param x,y Data frames
#' @param fill Missing columns in one data frame will be filled with this value
#'   (default is `NA`)
#'
#' @details Before calling [base::rbind()], it expands the columns of x and y so
#'   that they both share all of their columns.  If new columns are created,
#'   they are filled with the value of fill (with the default being `NA`)
#'
#' @return A data frame, the result of merging x and y by rows.
#' @export
rbind2.complete <- function(x, y, fill=NA) {
  x.diff <- setdiff(colnames(x), colnames(y))
  y.diff <- setdiff(colnames(y), colnames(x))
  x[, as.character(y.diff)] <- fill
  y[, as.character(x.diff)] <- fill
  return(rbind(x,y))
}

#' Reorder Levels of Factor
#' @description The levels of a factor are re-ordered so that the level
#'   specified by ref is first and the others are moved up.
#'
#' @param x Factor
#' @param ref String, the reference level of x to be moved to last
#' @param ... Arguments to be passed to [stats::relevel()] method
#'
#' @return A factor of the same length as x.
#' @export
relevel.last <- function(x, ref, ...) {
  x <- relevel(x, ref, ...)
  return(factor(x, levels = c(levels(x)[-1], levels(x)[1])))
}

#' Concatenate Species and Tissue Names
#' @description Pair-wise concatenate a vector of distinct species names and
#'   distinct tissue names, with the option of ignoring certain species. This is
#'   useful for plotting a set of species and tissues in a single color scheme,
#'   using a single legend.
#'
#' @param spec_names String vector, containing one or more species names
#' @param tissue_names String vector, containing one or more tissue names
#' @param ignore String vector, a subset of spec_names, the species names to be
#'   left unmodified (default `c("Homo sapiens")`)
#'
#' @details Uses [base::paste()] with sep='.'.
#'
#' @return A string vector of the concatenated values, all of the species-tissue
#'   combinations, joined separated by periods ('.').
#' @examples
#' paste.species_tissue(c("Mus musculus","Homo sapiens"), c("Blood","Liver","Skin"))
#' @export
paste.species_tissue <- Vectorize(function(spec_names, tissue_names, ignore=c("Homo sapiens")) {
  if (!spec_names %in% ignore) {
    return(paste(spec_names, tissue_names, sep='.'))
  }
  else {
    return(paste(spec_names))
  }
})


