#' MammalMethylClock: Tools for Building Mammalian Epigenetic Clocks
#'
#' @description Functions for applying published epigenetic clocks, and pipelines for building new epigenetic clocks for mammals. Utility functions for evaluating and visualizing results.
#' @name MammalMethylClock
#' @keywords internal
"_PACKAGE"
#'
## all dependencies
#' @import glmnet
#' @importFrom WGCNA transposeBigData rankPvalue standardScreeningBinaryTrait standardScreeningNumericTrait verboseScatterplot
#'
## all part of tidyverse
#' @import dplyr
#' @import tidyr
#' @import tibble
#' @import ggplot2
#'
#' @importFrom graphics abline legend mtext pairs par points text title
#' @importFrom grDevices dev.off png rainbow svg
#' @importFrom stats as.formula coef cor lm median na.exclude na.omit pnorm predict relevel residuals var
## have to use @importFrom stats due to error conflict with dplyr::filter and dplyr::lag
#' @importFrom utils read.csv write.table
NULL
