#' MammalMethylClock: Tools for Building Mammalian Epigenetic Clocks
#'
#' @description Functions for applying published epigenetic clocks, and pipelines for building new epigenetic clocks for mammals. Utility functions for evaluating and visualizing results.
#' @docType package
#' @name MammalMethylClock
#' @keywords internal
#'
#' @import glmnet
#' @importFrom WGCNA transposeBigData rankPvalue standardScreeningBinaryTrait standardScreeningNumericTrait verboseScatterplot
#'
#' @importFrom graphics abline legend mtext pairs par points text title
#' @importFrom grDevices dev.off png rainbow svg
#' @importFrom stats as.formula coef cor lm median na.exclude na.omit pnorm predict relevel residuals var
## have to use @importFrom stats due to error conflict with dplyr::filter and dplyr::lag
#' @importFrom utils read.csv write.table
#'
#' @import dplyr
#' @import tidyr
#' @importFrom tibble column_to_rownames rownames_to_column
# tibble installed with dplyr & tidyr
#' @import survival
#' @import ggplot2
#' @importFrom RColorBrewer brewer.pal
#' @importFrom snakecase to_upper_camel_case
#' @importFrom grid textGrob gpar grobHeight grid.draw convertX unit.c
#' @importFrom gridExtra tableGrob ttheme_default grid.arrange
#' @importFrom tab tabcoxph
#' @importFrom gtable gtable_add_rows gtable_add_grob
NULL
