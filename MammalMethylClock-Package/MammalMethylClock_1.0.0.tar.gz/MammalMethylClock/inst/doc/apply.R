## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message = FALSE----------------------------------------------------------
rm(list = ls())
options(stringAsFactors = F)
library(tidyverse)
library(MammalMethylClock)

## ----message = FALSE----------------------------------------------------------
download.file(
  "https://github.com/jazoller96/mammalian-methyl-clocks/raw/main/TutorialData/methdatConsortium_subset.rda",
  "methdatConsortium_subset.rda"
)
load("methdatConsortium_subset.rda")
file.remove("methdatConsortium_subset.rda")
datAllSamp <- methdatConsortium_subset
download.file(
  "https://github.com/jazoller96/mammalian-methyl-clocks/raw/main/TutorialData/infoConsortium.rda",
  "infoConsortium.rda"
)
load("infoConsortium.rda")
file.remove("infoConsortium.rda")
infoAllSamp <- infoConsortium
anAge <- getAnAgeTable() %>%
  dplyr::filter(profiled == T) %>%
  dplyr::mutate(gestationYears = Gestation.Incubation..days. / 365) %>%
  dplyr::select(SpeciesLatinName, averagedMaturity.yrs, maxAgeCaesar, gestationYears)
infoAllSamp <- base::merge(infoAllSamp, anAge, by = "SpeciesLatinName", all.x = T, sort = F)

yxs.list <- alignDatToInfo(infoAllSamp, datAllSamp, "SID", "SID")
ys <- yxs.list[[1]]
xs <- yxs.list[[2]]
ys$Tissue <- factor(ys$Tissue)
ys$SpeciesLatinName <- factor(ys$SpeciesLatinName)

## ----message = FALSE----------------------------------------------------------
OUTVAR <- "Age"
COLVAR <- "Tissue"
ys.output <- predictAge(xs, ys, tissue.names = c("Heart", "Muscle"), species.name = "Papio hamadryas")
head(ys.output)

output.csv <- "Baboon_ALL_Clock_PredictedValues.csv"
write.table(ys.output, output.csv, sep = ",", row.names = F, quote = F)

## ----message = FALSE----------------------------------------------------------
colnames(ys.output)

## ----message = FALSE----------------------------------------------------------
PREDVAR <- "DNAmAge.HumanBaboonAgeLogLinear"
out.png <- "HumanBaboon_Absolute_Clock_PredictedValues.png"
TITLE_str <- paste0("HumanBaboon_Absolute_Clock_PredictedValues", "\n")
saveValidationPlot(ys.output, OUTVAR, PREDVAR, COLVAR, out.png, TITLE_str)

## ----out.width = '70%', echo = FALSE------------------------------------------
knitr::include_graphics("HumanBaboon_Absolute_Clock_PredictedValues.png")

## ----message = FALSE, warning = FALSE-----------------------------------------
STRATVAR <- "Tissue"
ewas.csv.PREFIX <- "Baboon_EWASxTissue_LLin3Age"
ewas.png <- "Baboon_EWASxTissue_LLin3Age.png"
fun_VAR1 <- "averagedMaturity.yrs"
fun_VAR2 <- "maxAgeCaesar"
ewas.meta.table <- saveMetaEWAS(xs, ys, OUTVAR, STRATVAR, ewas.csv.PREFIX, ewas.png,
  fun_trans = fun_llin3.trans, fun_VAR1 = fun_VAR1, fun_VAR2 = fun_VAR2
)
head(ewas.meta.table)

## ----out.width = '70%', echo = FALSE------------------------------------------
knitr::include_graphics("Baboon_EWASxTissue_LLin3Age.png")

