## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----message = FALSE----------------------------------------------------------
rm(list = ls())
options(stringAsFactors = F)
library(tidyverse)
library(MammalMethylClock)

## ----message = FALSE----------------------------------------------------------
download.file(
  "https://github.com/jazoller96/mammalian-methyl-clocks/raw/main/TutorialData/methdatConsortium_subset.rda",
  "methdatConsortium_subset.rda"
)
load("methdatConsortium_subset.rda")
file.remove("methdatConsortium_subset.rda")
datAllSamp <- methdatConsortium_subset
download.file(
  "https://github.com/jazoller96/mammalian-methyl-clocks/raw/main/TutorialData/infoConsortium.rda",
  "infoConsortium.rda"
)
load("infoConsortium.rda")
file.remove("infoConsortium.rda")
infoAllSamp <- infoConsortium
anAge <- getAnAgeTable() %>%
  dplyr::filter(profiled == T) %>%
  dplyr::mutate(gestationYears = Gestation.Incubation..days. / 365) %>%
  dplyr::select(SpeciesLatinName, averagedMaturity.yrs, maxAgeCaesar, gestationYears)
infoAllSamp <- base::merge(infoAllSamp, anAge, by = "SpeciesLatinName", all.x = T, sort = F)

yxs.list <- alignDatToInfo(infoAllSamp, datAllSamp, "SID", "SID")
ys <- yxs.list[[1]]
xs <- yxs.list[[2]]
ys$Tissue <- factor(ys$Tissue)
ys$SpeciesLatinName <- factor(ys$SpeciesLatinName)

## ----message = FALSE----------------------------------------------------------
set.seed(1236)

## ----message = FALSE----------------------------------------------------------
OUTVAR <- "Age"
PREDVAR <- "DNAmAgebasedOnAll"
RESVAR <- "AgeAccelbasedOnAll"
RESinOtherVAR <- "AgeAccelinOtherbasedOnAll"
out.csv <- "Baboon_Clock_basedOnAll_EpigeneticLLin3Age.csv"
output.csv <- "Baboon_Clock_basedOnAll_EpigeneticLLin3Age_PredictedValues.csv"
out.png <- "Baboon_Clock_basedOnAll_EpigeneticLLin3Age.png"
out.png.title <- "Baboon_Clock_basedOnAll_EpigeneticLLin3Age"
fun_VAR1 <- "averagedMaturity.yrs"
fun_VAR2 <- NULL
ALPHA <- 0.5
NFOLD <- 10
ys.output <- saveBuildClock(
  xs.train = xs, ys.train = ys, xs.other = NULL, ys.other = NULL, OUTVAR,
  out.csv, output.csv, out.png, out.png.title,
  PREDVAR, RESVAR, RESinOtherVAR, ALPHA, NFOLD,
  fun_trans = fun_llin3.trans, fun_inv = fun_llin3.inv,
  fun_VAR1 = fun_VAR1, fun_VAR2 = fun_VAR2
)
head(ys.output)
head(read.csv(out.csv))

## ----out.width = '70%', echo = FALSE------------------------------------------
knitr::include_graphics("Baboon_Clock_basedOnAll_EpigeneticLLin3Age.png")

## ----message = FALSE----------------------------------------------------------
set.seed(12345)

## ----message = FALSE----------------------------------------------------------
OUTVAR <- "Age"
COLVAR <- "Tissue"
PREDVAR <- "DNAmAgeLOO"
RESVAR <- "AgeAccelLOO"
out.rdata <- NULL
output.csv <- "Baboon_LOO_Final_EpigeneticLLin3Age_PredictedValues.csv"
out.png <- "Baboon_LOO_Final_EpigeneticLLin3Age.png"
out.png.title <- "Baboon_LOO_Final_EpigeneticLLin3Age"
fun_VAR1 <- "averagedMaturity.yrs"
fun_VAR2 <- NULL
ALPHA <- 0.5
NFOLD <- 10
ys.output <- saveLOOEstimation(
  xs = xs, ys = ys, OUTVAR,
  out.rdata, output.csv, out.png, out.png.title,
  PREDVAR, RESVAR, ALPHA, NFOLD,
  fun_trans = fun_llin3.trans, fun_inv = fun_llin3.inv,
  fun_VAR1 = fun_VAR1, fun_VAR2 = fun_VAR2, COLVAR = COLVAR
)
head(ys.output)

## ----out.width = '70%', echo = FALSE------------------------------------------
knitr::include_graphics("Baboon_LOO_Final_EpigeneticLLin3Age.png")

## ----message = FALSE----------------------------------------------------------
PANELVAR <- "Tissue"
out.png <- "Baboon_LOO_Final_EpigeneticLLin3Age_PANEL.png"
TITLE_str <- paste0("Baboon_LOO_Final_EpigeneticLLin3Age by Tissue", "\n")
saveValidationPanelPlot(
  ys.output, OUTVAR, PREDVAR, PANELVAR,
  out.png, TITLE_str
)

## ----out.width = '70%', echo = FALSE------------------------------------------
knitr::include_graphics("Baboon_LOO_Final_EpigeneticLLin3Age_PANEL.png")

