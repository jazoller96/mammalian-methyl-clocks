## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup, message = FALSE---------------------------------------------------
rm(list = ls())
options(stringAsFactors = F)
library(tidyverse)
library(MammalMethylClock)

## ----message = FALSE----------------------------------------------------------
download.file(
  "https://github.com/jazoller96/mammalian-methyl-clocks/raw/main/TutorialData/methdatConsortium_subset.rda",
  "methdatConsortium_subset.rda"
)
load("methdatConsortium_subset.rda")
file.remove("methdatConsortium_subset.rda")
datAllSamp <- methdatConsortium_subset
head(datAllSamp[, 1:5])

download.file(
  "https://github.com/jazoller96/mammalian-methyl-clocks/raw/main/TutorialData/infoConsortium.rda",
  "infoConsortium.rda"
)
load("infoConsortium.rda")
file.remove("infoConsortium.rda")
infoAllSamp <- infoConsortium
head(infoAllSamp)

## ----message = FALSE----------------------------------------------------------
anAge <- getAnAgeTable() %>%
  dplyr::filter(profiled == T) %>%
  dplyr::mutate(gestationYears = Gestation.Incubation..days. / 365) %>%
  dplyr::select(SpeciesLatinName, averagedMaturity.yrs, maxAgeCaesar, gestationYears)
infoAllSamp <- base::merge(infoAllSamp, anAge, by = "SpeciesLatinName", all.x = T, sort = F)
head(infoAllSamp)

## ----message = FALSE----------------------------------------------------------
cat(sort(unique(infoAllSamp$Tissue)), sep = ", ")
cat(sort(unique(infoAllSamp$SpeciesLatinName)), sep = ", ")

nrow(infoAllSamp)
dim(datAllSamp)

## ----message = FALSE----------------------------------------------------------
yxs.list <- alignDatToInfo(infoAllSamp, datAllSamp, "SID", "SID")
ys <- yxs.list[[1]]
xs <- yxs.list[[2]]
rm(yxs.list)

ys$Tissue <- factor(ys$Tissue) # need to be factorized for package functions
ys$SpeciesLatinName <- factor(ys$SpeciesLatinName) # need to be factorized for package functions

## ----message = FALSE----------------------------------------------------------
table(ys$Tissue)
table(ys$SpeciesLatinName)

nrow(ys)
dim(xs)

